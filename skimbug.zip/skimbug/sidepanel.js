// Skimbug side panel. Talks to the page (content.js) for reading and to the background worker for models and blocking.
'use strict';
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nf = n => Math.round(n).toLocaleString(LANG === 'ru' ? 'ru-RU' : 'en-GB');
const mins = ms => Math.max(1, Math.round(ms / 60000));
const REDUCE = matchMedia('(prefers-reduced-motion: reduce)').matches;
const bg = msg => chrome.runtime.sendMessage(msg).catch(e => ({ ok: false, error: String(e && e.message || e) }));
let toastT = 0;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600); }

const DEFAULTS = {
  route: '', order: [], fallback: true, limitMode: 'auto', limit: 6000,
  exclude: 'mail.google.com\n*.bank\n*.gov', block: true, paused: [],
  lists: { easylist: true, easyprivacy: true, annoyances: true },
  crawler: true, crawlerKind: 'random', crawlerPal: 'random', hlMode: 'pos', followMouse: false, follow: true,
  focus: 'off', seenGuide: false, uiLang: '',
};
let S = { ...DEFAULTS };
let CONN = { list: [], health: {}, providers: {} };
async function save(patch) { Object.assign(S, patch); await chrome.storage.local.set({ settings: S }); }
async function loadConns() { const r = await bg({ type: 'connections' }); if (r && r.list) CONN = r; renderModels(); renderDeck(); }

/* ================= current tab ================= */
let tabId = null, tabUrl = '', PG = null, VIEW = { a: 0, b: 0 }, VIS = [], loadSeq = 0;
const sums = new Map(); // url -> last summary shown, so switching tabs keeps it
const hostOf = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } };
async function toPage(msg) { if (tabId == null) return null; try { return await chrome.tabs.sendMessage(tabId, { to: 'page', ...msg }); } catch (e) { return null; } }
async function ensureContent(tab) {
  let r = await toPage({ type: 'state' });
  if (r && !r.error) return true;
  try {
    await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['content.css'] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['crawler.js', 'content.js'] });
  } catch (e) { return false; }
  r = await toPage({ type: 'state' });
  return !!(r && !r.error);
}
async function load() {
  const seq = ++loadSeq;
  const forced = new URLSearchParams(location.search).get('tab'); // used by tests that open the panel as a page
  const tab = forced ? await chrome.tabs.get(+forced).catch(() => null) : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!tab) return;
  tabId = tab.id; tabUrl = tab.url || '';
  PG = null; VIS = [];
  if (!/^https?:/.test(tabUrl)) return showNoPage(tab, /^chrome|^edge|^about|^chrome-extension/.test(tabUrl) ? t("Browser pages can't be read by extensions. Open any website.") : tabUrl.startsWith('file:') ? t('To read files on your computer, allow it in chrome://extensions → Skimbug → Allow access to file URLs.') : t('Open a website and Skimbug reads it here.'));
  if (/^https:\/\/(chrome\.google\.com\/webstore|chromewebstore\.google\.com)/.test(tabUrl)) return showNoPage(tab, t("Chrome doesn't let extensions read the Web Store."));
  $('#dossier').dataset.state = 'loading'; $('#dz-host').textContent = hostOf(tabUrl); $('#dz-title').textContent = tab.title || t('Reading…');
  $('#dz-fav').textContent = (hostOf(tabUrl)[0] || '·').toUpperCase(); $('#dz-note').hidden = true;
  const ok = await ensureContent(tab);
  if (seq !== loadSeq) return;
  if (!ok) return showNoPage(tab, t("Skimbug can't reach this page. Reload it and open the panel again."));
  const snap = await toPage({ type: 'snapshot' });
  if (seq !== loadSeq) return;
  if (!snap || snap.error) return showNoPage(tab, t("This page didn't answer. Reload it and press the refresh button above."));
  PG = snap; VIEW = snap.view; VIS = snap.visible;
  const st = await toPage({ type: 'state' }) || {};
  showMap = !!st.outline; peekOn = !!st.peek; focusMode = st.focus || 'off';
  renderDossier(); renderLinksTab(); restoreSummary(); renderDeck(); renderBlockerControls(); refreshBlock();
}
function showNoPage(tab, note) {
  PG = null; lastNoPage = { tab, note };
  $('#dossier').dataset.state = 'none';
  $('#dz-host').textContent = hostOf(tab.url) || t('No page');
  $('#dz-kind').hidden = true;
  $('#dz-title').textContent = tab.title || t('Nothing to read here');
  $('#dz-note').textContent = note; $('#dz-note').hidden = false;
  $('#n-links').textContent = '0'; $('#n-block').textContent = '0';
  $('#keylinks-body').innerHTML = ''; $('#notable-body').innerHTML = '';
  $('#links-groups').innerHTML = `<p class="empty">${t('No links on this page.')}</p>`; $('#links-dropped').innerHTML = '';
  $('#links-count').textContent = '';
  resetSummaryView();
  renderDeck(); renderBlockerControls(); renderBlock(null, null);
}
chrome.tabs.onActivated.addListener(() => load());
chrome.tabs.onUpdated.addListener((id, info) => { if (id === tabId && (info.status === 'complete' || info.url)) { clearTimeout(updT); updT = setTimeout(load, info.url && !info.status ? 300 : 900); } });
chrome.windows?.onFocusChanged?.addListener(() => load());
let updT = 0, lastNoPage = null;
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.to !== 'panel' || !sender.tab || sender.tab.id !== tabId) return;
  if (msg.type === 'view' && PG) { VIEW = msg.view; VIS = msg.visible; moveWindow(); checkScreenStale(); }
});

/* ================= dossier + page map ================= */
const COL = { main: '#00E5FF', side: '#FF2BD6', junk: '#3A4558', ad: '#FF3B5C' };
const NAME = { main: 'Article', side: 'Side boxes', junk: 'Clutter', ad: 'Ads' };
const nameOf = k => t(NAME[k]);
let showMap = false;
function renderDossier() {
  $('#dossier').dataset.state = 'page';
  $('#dz-title').textContent = PG.title || PG.host;
  $('#dz-host').textContent = PG.host.replace(/^www\./, '');
  $('#dz-kind').textContent = t(PG.kind); $('#dz-kind').hidden = false;
  $('#dz-facts').innerHTML = t('{words} words · {min} min read · read in {ms} ms', { words: `<b>${nf(PG.words)}</b>`, n: PG.words, min: `<b>${Math.max(1, Math.round(PG.words / 220))}</b>`, ms: `<b>${PG.ms.toLocaleString(LANG === 'ru' ? 'ru-RU' : 'en-GB', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}</b>` }).split(' · ').map(x => `<span>${x}</span>`).join('');
  const cnt = PG.counts;
  $('#legend').innerHTML = Object.keys(cnt).map(k => `<span style="--c:${COL[k]}"><i></i>${nameOf(k)} <b>${k === 'main' ? '' : cnt[k]}</b></span>`).join('')
    + `<span><i class="on-screen"></i>${t('On screen')}</span>`
    + `<button type="button" id="map-toggle" aria-pressed="${showMap}">${showMap ? t('Hide outlines') : t('Outline on page')}</button>`;
  $('#map-toggle').onclick = async () => { showMap = !showMap; await toPage({ type: 'outline', on: showMap }); renderDossier(); };
  renderStrip();
}
const STRIP_PAD = 3;
function renderStrip() {
  const s = $('#strip'), inner = s.clientWidth - STRIP_PAD * 2;
  const order = { main: 0, junk: 1, side: 2, ad: 3 };
  const raw = PG.strip.segs.map(x => ({ ...x, label: t(x.label), a: x.a * inner, b: x.b * inner }));
  const merged = [];
  for (const t of Object.keys(order)) {
    const list = raw.filter(x => x.type === t).sort((p, q) => p.a - q.a);
    for (const x of list) {
      const last = merged.length && merged[merged.length - 1];
      if (last && last.type === t && x.a - last.b < 3) { last.b = Math.max(last.b, x.b); last.label += ', ' + x.label; }
      else merged.push({ ...x });
    }
  }
  s.innerHTML = merged.filter(x => x.b - x.a >= 3).map(x => {
    const l = Math.round(STRIP_PAD + x.a), w = Math.max(3, Math.round(x.b - x.a));
    const label = x.label.length > 120 ? x.label.slice(0, 117) + '…' : x.label;
    return `<span class="${x.type === 'ad' ? 'ad' : ''}" style="--c:${COL[x.type]};left:${l}px;width:${w}px" title="${esc(nameOf(x.type) + ': ' + label)}"></span>`;
  }).join('') + '<i class="win" id="strip-win"></i>';
  moveWindow();
}
function moveWindow() {
  const w = $('#strip-win'), s = $('#strip'); if (!w || !s || !VIEW) return;
  const out = 2, inner = s.clientWidth - STRIP_PAD * 2;
  let a = VIEW.a * inner, b = VIEW.b * inner;
  a = Math.max(0, Math.min(inner, a)); b = Math.max(0, Math.min(inner, b));
  if (b - a < 8) { const m = (a + b) / 2; a = Math.max(0, Math.min(inner - 8, m - 4)); b = a + 8; }
  w.style.left = Math.round(STRIP_PAD + a - out) + 'px'; w.style.width = Math.round(b - a + out * 2) + 'px';
}
$('#strip').addEventListener('click', e => {
  if (!PG) return;
  const r = $('#strip').getBoundingClientRect(); const f = (e.clientX - r.left - STRIP_PAD) / (r.width - STRIP_PAD * 2);
  toPage({ type: 'scrollTo', f: Math.max(0, Math.min(1, f)) });
});
new ResizeObserver(() => { if (PG) renderStrip(); moveInd(); }).observe($('#strip'));

/* ================= links ================= */
function lrow(l, i, why) {
  return `<li class="lrow"><span class="no">${i + 1}</span><a href="${esc(l.url)}" target="_blank" rel="noopener">${esc(l.text)}</a><button class="find" type="button" data-find="${esc(l.id)}">${t('Show')}</button>${why ? `<span class="why">${esc(why)}</span>` : ''}<span class="src">${esc(l.host)}, ${esc(l.block.toLowerCase() === 'article' ? t('in the article') : t(l.block))}</span></li>`;
}
function renderAlgoLinks() {
  const top = [...PG.links].sort((a, b) => b.score - a.score).slice(0, 5);
  $('#keylinks-body').innerHTML = top.map((l, i) => lrow(l, i)).join('') || `<li class="empty">${t('The article has no links.')}</li>`;
  $('#keylinks-tag').textContent = t('picked by the crawlers');
  const side = PG.side.filter(s => s.text.split(' ').length >= 4).slice(0, 4);
  $('#notable-body').innerHTML = side.map((l, i) => lrow(l, i)).join('') || `<li class="empty">${t('Nothing stands out.')}</li>`;
  $('#notable-tag').textContent = t('from side boxes');
}
function renderLinksTab() {
  const all = [...PG.links, ...PG.side];
  $('#n-links').textContent = all.length;
  $('#links-count').textContent = t('{n} links worth keeping', { n: all.length });
  const groups = [['source', t('Sources outside the site'), COL.main], ['related', t('Related on this site'), '#E6F1FF'], ['side', t('From side boxes'), COL.side]];
  $('#links-groups').innerHTML = groups.map(([g, name, c]) => {
    const items = all.filter(l => l.group === g); if (!items.length) return '';
    return `<div class="group"><h3 style="--c:${c}"><i></i>${name}<span class="tag">${items.length}</span></h3><ol class="ledger">${items.map((l, i) => lrow(l, i)).join('')}</ol></div>`;
  }).join('') || `<p class="empty">${t('No links worth keeping on this page.')}</p>`;
  const f = Object.entries(PG.dropped).sort((a, b) => b[1] - a[1]);
  $('#links-dropped').innerHTML = f.map(([k, n]) => `<dt>${esc(t(k))}</dt><dd>${n}</dd>`).join('') + `<dt><b style="color:var(--v-ivory);font-weight:500">${t('Total left out')}</b></dt><dd>${f.reduce((a, x) => a + x[1], 0)}</dd>`;
}
$('#copy-links').addEventListener('click', async () => {
  if (!PG) return;
  const all = [...PG.links, ...PG.side];
  const txt = all.map(l => `${l.text}\n${l.url}`).join('\n\n');
  try { await navigator.clipboard.writeText(txt); toast(t('Copied {n} links', { n: all.length })); }
  catch (e) { toast(t('Copy was blocked by the browser. Select the links instead.')); }
});

/* ================= models ================= */
const ordered = () => {
  const L = CONN.list, out = (S.order || []).map(id => L.find(c => c.id === id)).filter(Boolean);
  L.forEach(c => { if (!out.includes(c)) out.push(c); });
  return out;
};
const current = () => CONN.list.find(c => c.id === S.route) || ordered()[0] || null;
function connState(c) {
  const h = CONN.health[c.id];
  if (h && h.until > Date.now()) {
    const forever = h.until > Date.now() + 864e5 * 365;
    return { cls: forever ? 'off' : 'warn', text: forever ? t('Stopped: {why}', { why: tWhy(h.why, true) }) : t('Resting: {why}. Back in {m} min', { why: tWhy(h.why, true), m: mins(h.until - Date.now()) }), short: forever ? t('Stopped') : t('Back in {m} min', { m: mins(h.until - Date.now()) }), resting: true };
  }
  return { cls: '', text: t('Ready'), short: t('Ready') };
}
const ICON_UP = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="m6 15 6-6 6 6"/></svg>';
const ICON_DN = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="m6 9 6 6 6-6"/></svg>';
function renderModels() {
  const cur = current(), list = ordered();
  if (cur) { const st = connState(cur); $('#model-name').textContent = cur.name; $('#model-led').className = 'led ' + st.cls; }
  else { $('#model-name').textContent = t('Connect a model'); $('#model-led').className = 'led off'; }
  $('#backup-state').innerHTML = `<i class="led ${S.fallback && list.length > 1 ? '' : 'off'}"></i>${!S.fallback ? t('Backup off') : list.length > 1 ? t('Backup on, {n} more', { n: list.length - 1 }) : t('No backup yet')}`;
  $('#foot-ai').textContent = cur ? cur.name : t('No model connected');
  $('#foot-ai-dot').className = 'led ' + (cur ? connState(cur).cls : 'off');
  $('#routes').innerHTML = list.length ? list.map((c, i) => {
    const s = connState(c);
    return `<li class="route"><span class="pos">${i + 1}</span><b>${esc(c.name)}${c.id === (cur && cur.id) ? ` <span style="color:var(--v-ion);font-weight:400;font-size:12px">${t('picked')}</span>` : ''}</b><small><i class="led ${s.cls}" style="display:inline-block;margin-right:6px;vertical-align:1px;width:6px;height:6px"></i>${esc(s.text)} · <code>${esc(c.model)}</code>${c.keyHint ? ` · ${t('key')} <code>${esc(c.keyHint)}</code>` : ''}</small>
      <span class="acts">${s.resting ? `<button class="mini rst" type="button" data-reset="${esc(c.id)}">${t('Try now')}</button>` : ''}<button class="mini rm" type="button" data-rm="${esc(c.id)}">${t('Remove')}</button><button class="mini" type="button" data-move="${esc(c.id)}" data-dir="-1" aria-label="${esc(t('Move {name} up', { name: c.name }))}" ${i === 0 ? 'disabled' : ''}>${ICON_UP}</button><button class="mini" type="button" data-move="${esc(c.id)}" data-dir="1" aria-label="${esc(t('Move {name} down', { name: c.name }))}" ${i === list.length - 1 ? 'disabled' : ''}>${ICON_DN}</button></span></li>`;
  }).join('') : '';
  $('#routes').hidden = !list.length;
  if (!$('#model-pop').hidden) renderPop();
}
function renderPop() {
  const list = ordered(), cur = current();
  $('#model-pop').innerHTML = `<h4>${t('Which model answers')}</h4><p>${list.length ? t('If it fails, Skimbug moves down your backup list.') : t('No models yet. Paste a free key in Settings to start.')}</p>` + list.map(c => {
    const s = connState(c);
    return `<button class="opt" role="option" type="button" data-route="${esc(c.id)}" aria-selected="${cur && c.id === cur.id}"><i class="led ${s.cls}"></i><b>${esc(c.name)}</b><small>${esc(c.model)}</small><span class="st">${esc(s.short)}</span></button>`;
  }).join('') + `<div class="pop-foot"><span>${S.fallback ? t('Backup on') : t('Backup off')}</span><button type="button" id="pop-manage">${list.length ? t('Order and keys') : t('Connect a model')}</button></div>`;
  $('#pop-manage').onclick = () => { closePop(); selectTab('tab-settings'); };
}
function openPop() { renderPop(); const p = $('#model-pop'), b = $('#model-btn'); p.style.top = (b.offsetTop + b.offsetHeight + 8) + 'px'; p.hidden = false; b.setAttribute('aria-expanded', 'true'); }
function closePop() { $('#model-pop').hidden = true; $('#model-btn').setAttribute('aria-expanded', 'false'); }
$('#model-btn').addEventListener('click', e => { e.stopPropagation(); $('#model-pop').hidden ? openPop() : closePop(); });
$('#model-pop').addEventListener('click', async e => {
  e.stopPropagation();
  const o = e.target.closest('[data-route]'); if (!o) return;
  const c = CONN.list.find(x => x.id === o.dataset.route); if (!c) return;
  await save({ route: c.id }); closePop(); renderModels(); renderDeck(); toast(t('{name} will answer first', { name: c.name }));
});
document.addEventListener('click', e => { if (!$('#model-pop').hidden && !e.target.closest('#model-pop')) closePop(); });

/* ----- paste-any-key box (Settings and the guide share it) ----- */
const PROV_EN = { gemini: 'Google Gemini', openrouter: 'OpenRouter', groq: 'Groq', openai: 'OpenAI', anthropic: 'Anthropic', deepseek: 'DeepSeek', mistral: 'Mistral', ollama: 'Ollama on this computer', custom: 'Other compatible API' };
const provName = p => t(PROV_EN[p] || p);
const provShort = p => p === 'ollama' ? 'Ollama' : provName(p);
function pasteBox(root, prefix) {
  const HINT = () => t('Skimbug recognises Gemini, OpenRouter, Groq, OpenAI and Anthropic keys by their shape.');
  root.innerHTML = `
    <label class="fld">${t('Paste any API key')}<input id="${prefix}-key" type="password" placeholder="AIza…  sk-or-…  gsk_…  sk-…" autocomplete="off" spellcheck="false"></label>
    <div class="det" id="${prefix}-det" aria-live="polite">${HINT()}</div>
    <div class="choice" id="${prefix}-choice" role="group" aria-label="${t('Whose key is this?')}" hidden></div>
    <details class="adv" id="${prefix}-adv"><summary>${t('More options: Ollama, another address, a specific model')}</summary>
      <div class="choice" id="${prefix}-prov" role="group" aria-label="${t('Provider')}">${Object.keys(PROV_EN).map(k => `<button type="button" data-p="${k}" aria-pressed="false">${esc(provShort(k))}</button>`).join('')}</div>
      <label class="fld">${t('API address')}<input id="${prefix}-base" type="text" placeholder="${t('Filled in for known providers')}" autocomplete="off" spellcheck="false"><small>${t('Most providers speak the OpenAI format; paste the address from their docs.')}</small></label>
      <label class="fld">${t('Model ID')}<input id="${prefix}-model" type="text" placeholder="${t('Leave empty and Skimbug picks one')}" autocomplete="off" spellcheck="false"></label>
      <label class="fld">${t('Name in the list')}<input id="${prefix}-name" type="text" placeholder="${t('Optional')}" autocomplete="off"></label>
    </details>
    <div class="add-row"><button class="pill-btn go" id="${prefix}-go" type="button">${t('Connect')}</button></div>
    <div class="free-row"><span class="fine" style="margin:0">${t('Free keys:')}</span> <a class="key-link" href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Gemini</a><a class="key-link" href="https://openrouter.ai/keys" target="_blank" rel="noopener">OpenRouter</a><a class="key-link" href="https://console.groq.com/keys" target="_blank" rel="noopener">Groq</a></div>`;
  const q = id => root.querySelector('#' + prefix + '-' + id);
  let provider = '', dt = 0, busy = false;
  const setProv = (p, why) => {
    provider = p;
    root.querySelectorAll('[data-p]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.p === p)));
    const info = CONN.providers[p];
    if (info && info.base) q('base').value = info.base; else if (p === 'custom') q('base').value = '';
    if (why) { q('det').className = 'det'; q('det').innerHTML = why; }
  };
  const detect = async () => {
    const key = q('key').value.trim();
    q('choice').hidden = true;
    if (!key) { provider = ''; q('det').className = 'det'; q('det').textContent = HINT(); return; }
    const r = await bg({ type: 'detect', key });
    if (r.provider) setProv(r.provider, t('Looks like a {name} key.', { name: `<b>${esc(provName(r.provider))}</b>` }));
    else if (r.choices) {
      provider = '';
      q('det').className = 'det'; q('det').textContent = t('Whose key is this?');
      q('choice').innerHTML = r.choices.map(p => `<button type="button" data-p="${p}" aria-pressed="false">${esc(provName(p))}</button>`).join('');
      q('choice').hidden = false;
    }
  };
  q('key').addEventListener('input', () => { clearTimeout(dt); dt = setTimeout(detect, 180); });
  root.onclick = e => {
    const b = e.target.closest('[data-p]');
    if (b) {
      const p = b.dataset.p;
      setProv(p, p === 'ollama' ? t('Ollama needs no key. Make sure it is running, then press Connect.') : p === 'custom' ? t('Type the API address under More options, then press Connect.') : t('Using {name}.', { name: `<b>${esc(provName(p))}</b>` }));
      if (p === 'custom') q('adv').open = true;
      return;
    }
    if (e.target.closest('#' + prefix + '-go')) go();
  };
  async function go() {
    if (busy) return;
    const key = q('key').value.trim();
    const p = provider;
    if (!p) { q('det').className = 'det err'; q('det').textContent = key ? t('Pick whose key this is first.') : t('Paste a key first, or pick Ollama under More options.'); return; }
    busy = true; q('go').disabled = true; q('det').className = 'det'; q('det').innerHTML = `<span class="spin"></span> ${t('Checking the key with the provider…')}`;
    const r = await bg({ type: 'connect', provider: p, key, base: q('base').value.trim(), model: q('model').value.trim(), name: q('name').value.trim() });
    busy = false; q('go').disabled = false;
    if (r && r.ok) {
      q('key').value = ''; q('model').value = ''; q('name').value = ''; provider = '';
      q('base').value = ''; q('choice').hidden = true; q('adv').open = false;
      q('det').className = 'det ok'; q('det').innerHTML = t('Connected {name}, using {model}.', { name: `<b>${esc(r.connection.name)}</b>`, model: esc(r.connection.model) });
      root.querySelectorAll('[aria-pressed="true"]').forEach(b => b.setAttribute('aria-pressed', 'false'));
      await loadConns(); toast(t('{name} is ready', { name: r.connection.name }));
    } else {
      q('det').className = 'det err';
      q('det').textContent = !r || !r.error ? t('Something went wrong. Try again.') : /^[a-z]/.test(r.error) ? `${provShort(p)} ${tWhy(r.error)}.` : t(r.error);
    }
  }
}

$('#pane-settings').addEventListener('click', async e => {
  const rm = e.target.closest('[data-rm]');
  if (rm) { const c = CONN.list.find(x => x.id === rm.dataset.rm); await bg({ type: 'disconnect', id: rm.dataset.rm }); await loadConns(); if (c) toast(t('Removed {name}. Its key is deleted from this browser.', { name: c.name })); return; }
  const rs = e.target.closest('[data-reset]');
  if (rs) { await bg({ type: 'resetHealth', id: rs.dataset.reset }); await loadConns(); toast(t('It will be asked first again')); return; }
  const m = e.target.closest('[data-move]');
  if (m) {
    const order = ordered().map(c => c.id), i = order.indexOf(m.dataset.move), j = i + Number(m.dataset.dir);
    if (j < 0 || j >= order.length) return;
    [order[i], order[j]] = [order[j], order[i]];
    await save({ order }); renderModels();
  }
});

/* ================= summaries ================= */
function excludedHere() {
  if (!PG) return false;
  const h = PG.host.toLowerCase().replace(/^www\./, '');
  return S.exclude.split('\n').map(x => x.trim().toLowerCase()).filter(Boolean).some(p => p.startsWith('*.') ? (h.endsWith(p.slice(1)) || h === p.slice(2)) : (h === p.replace(/^www\./, '') || h.endsWith('.' + p)));
}
let busy = false;
const rangeLabel = ids => !ids.length ? t('no article text') : ids.length === 1 ? t('paragraph {a}', { a: ids[0] + 1 }) : t('paragraphs {a} to {b}', { a: ids[0] + 1, b: ids[ids.length - 1] + 1 });
function estimate() {
  const c = current(); const lim = S.limitMode === 'auto' ? (c ? (c.provider === 'groq' ? 6000 : c.provider === 'gemini' || ['openai', 'anthropic', 'deepseek', 'mistral'].includes(c.provider) ? 12000 : 8000) : 8000) : S.limit;
  const chars = PG.paras.reduce((a, p) => a + p.text.length + 8, 0) + 1200 + Math.min(PG.links.length, 30) * 90 + Math.min(PG.side.length, 20) * 60;
  return Math.min(Math.round(chars / 4), lim + 700);
}
function renderDeck() {
  const why = !PG ? t('Open an article and Skimbug can summarize it.')
    : excludedHere() ? t('{host} is on your never-send list, so Summarize is off here.', { host: PG.host.replace(/^www\./, '') })
    : PG.sensitive ? t('This page has a password or card field, so Summarize stays off.')
    : !PG.paras.length ? t('Skimbug found no readable text on this page.')
    : !CONN.list.length ? 'none' : '';
  $$('.sum').forEach(b => b.disabled = (!!why && why !== 'none') || busy);
  if (busy) return;
  if (why === 'none') { $('#sum-meta').innerHTML = t('No model connected yet. {link} to turn on Summarize.', { link: `<button type="button" id="go-connect">${t('Paste a free key')}</button>` }); $('#go-connect').onclick = () => selectTab('tab-settings'); return; }
  if (why) { $('#sum-meta').textContent = why; return; }
  if (!sums.get(PG.url)) $('#sum-meta').textContent = t('About {n} tokens in one request. Nothing is sent until you press.', { n: nf(estimate()), raw: estimate() });
}
const ERR_EN = {
  all_failed: 'None of your models answered. Check your keys in Settings or try again in a few minutes.',
  no_fallback: 'The model failed and switching is off. Pick another model or turn switching on in Settings.',
  no_models: 'Connect a model first: Settings, then Models.',
};
const errText = code => t(ERR_EN[code] || ERR_EN.all_failed);
function skel(n) { return `<div class="skel">${'<i></i>'.repeat(n)}</div>`; }
function revealText(el, text) {
  let i = 0;
  const html = esc(text).split(/(\s+)/).map(w => /^\s+$/.test(w) ? w : `<span class="wd" style="--i:${Math.min(i++, 90)}">${w}</span>`).join('');
  el.innerHTML = `<p class="about reveal">${html}</p>`;
}
let lastFb = null;
function showFallback(res) {
  lastFb = res;
  const a = $('#fb-alert');
  if (!res.skipped || !res.skipped.length) { a.hidden = true; return; }
  const s = res.skipped[0];
  const back = s.until ? ' ' + t('Skimbug will try it again in {m} min.', { m: mins(s.until - Date.now()) }) : '';
  a.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 9v4M12 17h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/></svg><span>${res.used ? t('{name} {why}, so {used} answered instead.', { name: `<b>${esc(s.name)}</b>`, why: esc(tWhy(s.why)), used: `<b>${esc(res.used.name)}</b>` }) : `<b>${esc(s.name)}</b> ${esc(tWhy(s.why))}.`}${back}</span><button type="button" aria-label="${t('Dismiss')}">&times;</button>`;
  a.hidden = false; a.querySelector('button').onclick = () => a.hidden = true;
}
function metaOf(sum) {
  if (!sum.used) return '';
  return sum.cached ? t('{name} answered from saved answers.', { name: sum.used })
    : sum.secs < 1 ? t('{name} answered in {ms} ms.', { name: sum.used, ms: Math.max(1, Math.round(sum.secs * 1000)) })
    : t('{name} answered in {s} s.', { name: sum.used, s: sum.secs.toLocaleString(LANG === 'ru' ? 'ru-RU' : 'en-GB', { maximumFractionDigits: 1, minimumFractionDigits: 1 }) });
}
let sumLang = null;
function pageForModel(onlyScreen) {
  return { url: PG.url, host: PG.host, title: PG.title, paras: PG.paras, visible: VIS, links: PG.links, side: PG.side, onlyScreen };
}
function resetSummaryView() {
  $('#about-body').innerHTML = `<p class="empty">${t('Press Summarize and the model explains this page in two or three sentences. Nothing is sent before you press.')}</p>`;
  $('#screen-body').innerHTML = `<p class="empty">${t('A closer retelling of only what is visible in the window. Appears after Summarize.')}</p>`;
  $('#about-tag').textContent = ''; $('#screen-tag').textContent = ''; $('#screen-refresh').hidden = true; $('#fb-alert').hidden = true;
}
function applySummary(sum, animate) {
  const out = sum.out || {};
  const about = typeof out.about === 'string' ? out.about : '';
  const pts = Array.isArray(out.onScreen) ? out.onScreen.filter(s => typeof s === 'string') : [];
  if (animate) revealText($('#about-body'), about || t('The model returned no overview.'));
  else $('#about-body').innerHTML = `<p class="about">${esc(about || t('The model returned no overview.'))}</p>`;
  $('#about-tag').textContent = sum.lang === 'ru' ? t('Russian') : t('English');
  renderScreen(sum.screen || pts, sum.screenAt || sum.vis, animate);
  const byId = new Map([...PG.links, ...PG.side].map(l => [l.id, l]));
  const kl = (Array.isArray(out.keyLinks) ? out.keyLinks : []).map(x => ({ l: byId.get(String(x && x.id)), why: String(x && x.why || '') })).filter(x => x.l && x.l.group !== 'side');
  if (kl.length) { $('#keylinks-body').innerHTML = kl.map((x, i) => lrow(x.l, i, x.why)).join(''); $('#keylinks-tag').textContent = t('picked by the model'); }
  else renderAlgoLinksKeyOnly();
  const wn = (Array.isArray(out.worthNoting) ? out.worthNoting : []).map(x => ({ l: byId.get(String(x && x.id)), why: String(x && x.why || '') })).filter(x => x.l);
  $('#notable-body').innerHTML = wn.length ? wn.map((x, i) => lrow(x.l, i, x.why)).join('') : `<li class="empty">${t('Nothing in the side boxes is about this article.')}</li>`;
  $('#notable-tag').textContent = t('picked by the model');
}
function renderAlgoLinksKeyOnly() {
  const top = [...PG.links].sort((a, b) => b.score - a.score).slice(0, 5);
  $('#keylinks-body').innerHTML = top.map((l, i) => lrow(l, i)).join('') || `<li class="empty">${t('The article has no links.')}</li>`;
  $('#keylinks-tag').textContent = t('picked by the crawlers');
}
function restoreSummary() {
  const sum = sums.get(PG.url);
  $('#fb-alert').hidden = true;
  if (!sum) { resetSummaryView(); renderAlgoLinks(); return; }
  applySummary(sum, false);
  $('#sum-meta').textContent = metaOf(sum);
  checkScreenStale();
}
function renderScreen(pts, vis, animate) {
  $('#screen-tag').textContent = rangeLabel(vis || []);
  if (!pts.length) { $('#screen-body').innerHTML = `<p class="empty">${t('There is no article text on screen.')}</p>`; return; }
  let i = 0;
  const words = s => esc(s).split(/(\s+)/).map(w => /^\s+$/.test(w) || !animate ? w : `<span class="wd" style="--i:${Math.min(i++, 120)}">${w}</span>`).join('');
  $('#screen-body').innerHTML = `<ul class="pts${animate ? ' reveal' : ''}">${pts.map(s => `<li>${words(s)}</li>`).join('')}</ul>`;
}
async function summarize(lang) {
  if (busy || !PG) return;
  busy = true; closePop();
  const url = PG.url, vis = [...VIS], t0 = performance.now();
  $$('.sum').forEach(b => { b.disabled = true; b.classList.toggle('busy', b.dataset.lang === lang); b.classList.toggle('primary', b.dataset.lang === lang); });
  sumLang = lang;
  $('#sum-meta').textContent = t('Reading the article…');
  $('#fb-alert').hidden = true;
  $('#about-body').innerHTML = skel(3); $('#screen-body').innerHTML = skel(4); $('#screen-refresh').hidden = true;
  try {
    const res = await bg({ type: 'summarize', page: pageForModel(false), lang, onlyScreen: false });
    if (!PG || PG.url !== url) return;
    if (!res || !res.ok) throw res || { code: 'all_failed' };
    const secs = (performance.now() - t0) / 1000;
    const sum = { lang, out: res.out, vis, screenAt: vis, used: res.used.name, cached: !!res.cached, secs };
    sums.set(url, sum);
    applySummary(sum, !REDUCE);
    showFallback(res);
    $('#sum-meta').textContent = metaOf(sum);
    if (S.follow) toPage({ type: 'followWords', text: [res.out.about, ...(res.out.onScreen || [])].join(' ') });
  } catch (e) {
    const code = e && e.code;
    $('#sum-meta').textContent = ERR_EN[code] ? errText(code) : (e && e.error) ? t(e.error) : errText('all_failed');
    if (e && e.skipped && e.skipped.length) showFallback({ skipped: e.skipped });
    const prev = sums.get(url);
    if (prev) applySummary(prev, false); else { $('#about-body').innerHTML = `<p class="empty">${t('No overview yet.')}</p>`; $('#screen-body').innerHTML = `<p class="empty">${t('No retelling yet.')}</p>`; }
  } finally {
    busy = false;
    $$('.sum').forEach(b => b.classList.remove('busy'));
    await loadConns();
  }
}
async function refreshScreen() {
  const sum = PG && sums.get(PG.url);
  if (busy || !sum) return;
  const vis = [...VIS]; if (!vis.length) { toast(t('There is no article text on screen.')); return; }
  busy = true; const url = PG.url;
  $('#screen-refresh').hidden = true; $('#screen-body').innerHTML = skel(3); renderDeck();
  try {
    const res = await bg({ type: 'summarize', page: pageForModel(true), lang: sum.lang, onlyScreen: true });
    if (!res || !res.ok) throw res || {};
    const pts = Array.isArray(res.out.onScreen) ? res.out.onScreen.filter(s => typeof s === 'string') : [];
    sum.screen = pts; sum.screenAt = vis;
    if (PG && PG.url === url) { renderScreen(pts, vis, !REDUCE); showFallback(res); }
    if (S.follow) toPage({ type: 'followWords', text: pts.join(' ') });
  } catch (e) {
    $('#screen-body').innerHTML = `<p class="empty">${esc(errText(e && e.code))}</p>`;
  } finally { busy = false; await loadConns(); }
}
function checkScreenStale() {
  const sum = PG && sums.get(PG.url);
  if (!sum || busy) { $('#screen-refresh').hidden = true; return; }
  const at = sum.screenAt || [];
  const same = VIS.length && at.length && VIS.filter(i => at.includes(i)).length / VIS.length > .5;
  $('#screen-refresh').hidden = !!same || !VIS.length;
}
function onSum(lang) {
  if (!CONN.list.length) { selectTab('tab-settings'); $('#pk-key').focus(); toast(t('Paste a free key to turn on Summarize')); return; }
  summarize(lang);
}
$('#sum-en').addEventListener('click', () => onSum('en'));
$('#sum-ru').addEventListener('click', () => onSum('ru'));
$('#screen-refresh').addEventListener('click', refreshScreen);
document.addEventListener('click', async e => {
  const f = e.target.closest('[data-find]');
  if (f) { const r = await toPage({ type: 'find', id: f.dataset.find }); if (!r || !r.ok) toast(t('That link is no longer on the page')); }
});

/* ================= blocker ================= */
let peekOn = false, focusMode = 'off', blkTimer = 0;
const siteKey = () => PG ? PG.host.replace(/^www\./, '') : hostOf(tabUrl);
function renderBlockerControls() {
  const h = siteKey(), paused = !!h && (S.paused || []).includes(h);
  $('#block-on').checked = S.block;
  $('#block-site-off').checked = paused; $('#block-site-off').disabled = !h || !S.block;
  $('#pause-label').textContent = h ? t('Pause on {host}', { host: h }) : t('Pause on this site');
  $('#block-peek').checked = peekOn; $('#block-peek').disabled = !PG;
  $$('[data-list]').forEach(i => { i.checked = S.lists[i.dataset.list] !== false; i.disabled = !S.block; });
  $$('#focus-mode button').forEach(b => { b.setAttribute('aria-pressed', String(b.dataset.v === focusMode)); b.disabled = !PG; });
  $('#foot-block').textContent = !S.block ? t('Blocker off') : paused ? t('Paused on this site') : t('Blocker on');
  $('#foot-block-dot').className = 'led ' + (!S.block ? 'off' : paused ? 'warn' : '');
}
async function refreshBlock() {
  clearTimeout(blkTimer);
  if (tabId == null) return;
  const [net, cos] = await Promise.all([bg({ type: 'blockStats', tabId }), PG ? toPage({ type: 'blockInfo' }) : null]);
  renderBlock(net, cos);
}
function renderBlock(net, cos) {
  const req = net && net.total || 0, hid = cos && cos.total || 0;
  const paused = (S.paused || []).includes(siteKey());
  const total = S.block && !paused ? req + hid : 0;
  $('#blk-num').textContent = nf(total); $('#blk-num').classList.toggle('off', !S.block || paused);
  $('#n-block').textContent = total;
  $('#blk-cap').innerHTML = !S.block ? t('Blocking is off everywhere') : paused ? t('Blocking is paused on {host}', { host: `<b>${esc(siteKey())}</b>` }) : t('things removed from this page before you saw them');
  $('#st-req').textContent = S.block && !paused ? nf(req) : '0';
  $('#st-ads').textContent = S.block && !paused ? nf(cos && cos.by && cos.by.ads || 0) : '0';
  $('#st-annoy').textContent = S.block && !paused ? nf(cos && cos.by && cos.by.annoyances || 0) : '0';
  const NAMES = { easylist: 'EasyList', easyprivacy: 'EasyPrivacy', annoyances: t('Cookie and annoyance lists'), ads: 'EasyList' };
  const rows = [];
  if (net && net.by) for (const [k, n] of Object.entries(net.by)) rows.push(`<li><code>${esc(t(k === 'easyprivacy' ? 'tracker requests' : k === 'easylist' ? 'ad requests' : 'banner scripts'))}</code><small>${esc(NAMES[k] || k)}, ${t('network')}</small><b>${n}</b></li>`);
  if (cos && cos.rules) for (const r of cos.rules) rows.push(`<li><code>${r.sel.startsWith('Skimbug:') ? esc(t(r.sel.slice(9))) : '##' + esc(r.sel)}</code><small>${esc(r.list === 'ads' ? 'EasyList' : t('Cookie and annoyance lists'))}, ${t('hidden on the page')}</small><b>${r.n}</b></li>`);
  $('#rules-hit').innerHTML = S.block && !paused && rows.length ? rows.join('') : `<li class="empty" style="display:block;border:0">${t('Nothing caught on this page yet.')}</li>`;
  if (net && net.error && /quota|limit/i.test(net.error)) $('#st-req').textContent = '—';
}
$('#block-on').addEventListener('change', async e => { await save({ block: e.target.checked }); await bg({ type: 'syncBlocking' }); renderBlockerControls(); toast(S.block ? t('Ads are blocked on every site. Reload open pages to clear them.') : t('Blocking is off. Reload a page to see it with ads.')); refreshBlock(); });
$('#block-site-off').addEventListener('change', async e => {
  const h = siteKey(); if (!h) return;
  const set = new Set(S.paused || []); e.target.checked ? set.add(h) : set.delete(h);
  await save({ paused: [...set] }); await bg({ type: 'syncBlocking' }); renderBlockerControls();
  toast(e.target.checked ? t('Paused on {host}. Reloading the page.', { host: h }) : t('Blocking again on {host}. Reloading the page.', { host: h }));
  if (tabId != null) chrome.tabs.reload(tabId);
});
$('#block-peek').addEventListener('change', async e => {
  peekOn = e.target.checked; const r = await toPage({ type: 'peek', on: peekOn });
  if (peekOn) toast(r && r.n ? t('{n} hidden blocks are back, outlined in red', { n: r.n }) : t('Nothing was hidden on this page'));
});
$$('[data-list]').forEach(i => i.addEventListener('change', async () => { await save({ lists: { ...S.lists, [i.dataset.list]: i.checked } }); await bg({ type: 'syncBlocking' }); toast(t('Saved. Reload pages to apply.')); refreshBlock(); }));
$('#focus-mode').addEventListener('click', async e => {
  const b = e.target.closest('button'); if (!b || !PG) return;
  const r = await toPage({ type: 'focus', mode: b.dataset.v }); focusMode = r && r.mode || 'off';
  renderBlockerControls();
  toast(focusMode === 'off' ? t('Page restored') : focusMode === 'dim' ? t('Everything except the article is faded') : t('Only the article and the logo are left'));
});

/* ================= settings ================= */
function syncLimit() {
  $$('#limit-mode button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === S.limitMode)));
  $('#limit-custom').hidden = S.limitMode !== 'custom';
  $('#set-limit').value = S.limit; $('#limit-val').textContent = nf(S.limit);
}
$$('#limit-mode button').forEach(b => b.addEventListener('click', async () => { await save({ limitMode: b.dataset.v }); syncLimit(); renderDeck(); }));
$('#set-limit').addEventListener('input', e => { S.limit = +e.target.value; $('#limit-val').textContent = nf(S.limit); renderDeck(); });
$('#set-limit').addEventListener('change', () => save({}));
let exT = 0;
$('#set-exclude').addEventListener('input', e => { S.exclude = e.target.value; renderDeck(); clearTimeout(exT); exT = setTimeout(() => save({}), 400); });
$('#set-fallback').addEventListener('change', async e => { await save({ fallback: e.target.checked }); renderModels(); });
$('#set-crawler').addEventListener('change', async e => { await save({ crawler: e.target.checked }); toast(S.crawler ? t('The crawler is back') : t('No crawler on pages')); });
$('#set-follow').addEventListener('change', e => save({ follow: e.target.checked }));
async function setFollow(v) {
  const patch = { followMouse: v }; if (v && !S.crawler) patch.crawler = true;
  await save(patch); syncSettingsUI();
  toast(v ? t('The crawler now follows your mouse and marks what it crosses') : t('The crawler is back to reading on its own'));
}
$('#sb-follow-btn').addEventListener('click', () => setFollow(!S.followMouse));
$('#set-follow-mouse').addEventListener('change', e => setFollow(e.target.checked));
const POS = {
  noun: { name: 'Nouns', c: '#00E5FF', ex: 'robot, rubble', exRu: 'робот, завал' }, verb: { name: 'Verbs', c: '#FF2BD6', ex: 'crawled, keeps', exRu: 'прополз, идёт' },
  adj: { name: 'Adjectives', c: '#FFB020', ex: 'narrow, cheap', exRu: 'узкий, дешёвый' }, adv: { name: 'Adverbs', c: '#7CFF6B', ex: 'simply, far', exRu: 'просто, далеко' },
  name: { name: 'Names', c: '#A98BFF', ex: 'Okafor, Lattice', exRu: 'Окафор, Москва' }, num: { name: 'Numbers', c: '#FF7A45', ex: '40, 1.2m', exRu: '40, 1,2 млн' },
  other: { name: 'Everything else', c: '#8FA3BF', ex: 'about, which', exRu: 'о, который' },
};
function renderPosLegend() {
  $('#pos-legend').innerHTML = Object.values(POS).map(p => `<li><i style="--c:${p.c}"></i>${t(p.name)}<small>${LANG === 'ru' ? p.exRu : p.ex}</small></li>`).join('');
  $('#pos-legend').hidden = S.hlMode !== 'pos';
  $$('#hl-mode button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === S.hlMode)));
}
$('#hl-mode').addEventListener('click', async e => { const b = e.target.closest('button'); if (!b) return; await save({ hlMode: b.dataset.v }); renderPosLegend(); });
$('#clear-cache').addEventListener('click', async () => { await chrome.storage.local.remove('cache'); sums.clear(); if (PG) restoreSummary(); renderDeck(); toast(t('Saved answers forgotten')); });
function syncSettingsUI() {
  $('#set-fallback').checked = S.fallback; $('#set-crawler').checked = S.crawler; $('#set-follow').checked = S.follow;
  $('#set-follow-mouse').checked = S.followMouse; $('#sb-follow-btn').setAttribute('aria-pressed', String(S.followMouse));
  if (document.activeElement !== $('#set-exclude')) $('#set-exclude').value = S.exclude;
  syncLimit(); renderPosLegend(); syncGallery();
}

/* ----- crawler gallery ----- */
const { Crawler, PALS, rnd, pick } = self.SBC;
const minis = [];
function buildGallery() {
  $$('.bug-card[data-kind]').forEach(btn => {
    const kind = btn.dataset.kind; if (kind === 'random') return;
    const cv = btn.querySelector('canvas'), c = new Crawler(kind, 0, 0, 0, S.crawlerPal);
    c.demo = { t: rnd(0, 6), r: kind === 'centipede' ? 105 : kind === 'beetle' ? 46 : 52 };
    minis.push({ cv, ctx: cv.getContext('2d'), c, scale: kind === 'centipede' ? .46 : kind === 'beetle' ? .95 : .8 });
    for (let s = 0; s < 60; s++) c.update(1 / 60, 0);
  });
  renderSwatches();
}
function renderSwatches() {
  $('#swatches').innerHTML = `<button class="swatch rand" type="button" role="radio" data-pal="random" aria-label="${t('Random colour')}"></button>` +
    Object.entries(PALS).map(([k, p]) => `<button class="swatch" type="button" role="radio" data-pal="${k}" style="--c:${p.line}" aria-label="${t('{name} colour', { name: k })}"></button>`).join('');
  syncGallery();
}
function syncGallery() {
  $$('.bug-card').forEach(b => b.setAttribute('aria-checked', String(b.dataset.kind === S.crawlerKind)));
  $$('.swatch').forEach(b => b.setAttribute('aria-checked', String(b.dataset.pal === S.crawlerPal)));
  minis.forEach(m => { if (PALS[S.crawlerPal]) m.c.pal = PALS[S.crawlerPal]; });
}
$('#bug-grid').addEventListener('click', async e => {
  const b = e.target.closest('.bug-card'); if (!b) return;
  await save({ crawlerKind: b.dataset.kind }); syncGallery();
  toast(b.dataset.kind === 'random' ? t('A different crawler on every page') : t('Your crawler is now the {kind}', { kind: t(b.dataset.kind) }));
});
$('#swatches').addEventListener('click', async e => {
  const b = e.target.closest('.swatch'); if (!b) return;
  await save({ crawlerPal: b.dataset.pal });
  if (S.crawlerPal === 'random') minis.forEach(m => m.c.pal = PALS[pick(Object.keys(PALS))]);
  syncGallery();
});
let last = performance.now();
function frame(now) {
  const dt = Math.min(.04, (now - last) / 1000); last = now;
  if (!$('#pane-settings').hidden && !document.hidden) for (const m of minis) {
    const w = m.cv.clientWidth, h = m.cv.clientHeight; if (!w) continue;
    const d = Math.min(2, devicePixelRatio || 1);
    if (m.cv.width !== Math.round(w * d)) { m.cv.width = Math.round(w * d); m.cv.height = Math.round(h * d); }
    if (!REDUCE) m.c.update(dt, 0);
    m.ctx.setTransform(1, 0, 0, 1, 0, 0); m.ctx.clearRect(0, 0, m.cv.width, m.cv.height);
    m.ctx.setTransform(d * m.scale, 0, 0, d * m.scale, m.cv.width / 2, m.cv.height / 2);
    m.ctx.lineCap = 'square'; m.ctx.lineJoin = 'miter';
    m.c.draw(m.ctx);
  }
  requestAnimationFrame(frame);
}

/* ================= tabs, guide ================= */
function moveInd() {
  const t = $('.tabs [aria-selected="true"]'), ind = $('#tab-ind'); if (!t) return;
  ind.style.width = (t.offsetWidth - 28) + 'px'; ind.style.transform = `translateX(${t.offsetLeft + 14}px)`;
}
function selectTab(id) {
  $$('.tabs [role=tab]').forEach(x => x.setAttribute('aria-selected', String(x.id === id)));
  $$('.pane').forEach(p => p.hidden = p.id !== $('#' + id).getAttribute('aria-controls'));
  $('#sb-body').scrollTop = 0; moveInd();
  if (id === 'tab-block') refreshBlock();
}
$$('.tabs [role=tab]').forEach(t => t.addEventListener('click', () => selectTab(t.id)));
let gStep = 0;
function renderGuide() {
  $$('.g-step').forEach(s => s.hidden = Number(s.dataset.step) !== gStep);
  $$('#g-prog i').forEach((i, k) => i.classList.toggle('on', k <= gStep));
  $('#g-back').style.visibility = gStep ? 'visible' : 'hidden';
  $('#g-next').textContent = gStep === 3 ? t('Start reading') : gStep === 2 && !CONN.list.length ? t('Later') : t('Next');
  $('.g-body').scrollTop = 0;
}
function openGuide() { gStep = 0; $('#guide').hidden = false; renderGuide(); $('#g-next').focus({ preventScroll: true }); }
function closeGuide() { $('#guide').hidden = true; save({ seenGuide: true }); }
$('#g-next').addEventListener('click', () => { if (gStep < 3) { gStep++; renderGuide(); } else closeGuide(); });
$('#g-back').addEventListener('click', () => { if (gStep) { gStep--; renderGuide(); } });
$('#g-skip').addEventListener('click', closeGuide);
$('#sb-guide-btn').addEventListener('click', openGuide);
$('#show-guide').addEventListener('click', openGuide);
$('#sb-reload').addEventListener('click', () => { load(); toast(t('Reading the page again')); });
addEventListener('keydown', e => { if (e.key === 'Escape') { if (!$('#model-pop').hidden) closePop(); else if (!$('#guide').hidden) closeGuide(); } });

/* ================= language ================= */
function setLangUI() {
  const fbShown = !$('#fb-alert').hidden;
  LANG = S.uiLang === 'ru' ? 'ru' : 'en';
  document.documentElement.lang = LANG;
  applyStatic(LANG);
  $$('#ui-lang button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === LANG)));
  if (!busy && !sumLang) $$('.sum').forEach(b => b.classList.toggle('primary', b.dataset.lang === LANG));
  pasteBox($('#paste-box'), 'pk'); pasteBox($('#guide-paste'), 'gk');
  renderSwatches(); syncSettingsUI(); renderModels(); renderBlockerControls();
  if (PG) { renderDossier(); renderLinksTab(); restoreSummary(); refreshBlock(); } else if (lastNoPage) load();
  renderDeck();
  renderGuide();
  if (lastFb && fbShown) showFallback(lastFb);
  moveInd();
}
function openLangPick() {
  $('#lang-pick').hidden = false;
  const guess = (navigator.language || '').toLowerCase().startsWith('ru') ? 'ru' : 'en';
  $(`#lang-pick [data-lang="${guess}"]`).focus({ preventScroll: true });
}
$('#lang-pick').addEventListener('click', async e => {
  const b = e.target.closest('[data-lang]'); if (!b) return;
  await save({ uiLang: b.dataset.lang }); setLangUI();
  $('#lang-pick').hidden = true;
  if (!S.seenGuide) openGuide();
});
$('#ui-lang').addEventListener('click', async e => {
  const b = e.target.closest('[data-v]'); if (!b || b.dataset.v === LANG) return;
  await save({ uiLang: b.dataset.v }); setLangUI();
  toast(LANG === 'ru' ? 'Интерфейс на русском' : 'Interface in English');
});

/* ================= storage sync + boot ================= */
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === 'local' && ch.settings) {
    S = { ...DEFAULTS, ...ch.settings.newValue };
    if ((S.uiLang === 'ru' ? 'ru' : 'en') !== LANG) setLangUI();
    syncSettingsUI(); renderModels(); renderBlockerControls();
  }
  if (area === 'local' && ch.connections) loadConns();
  if (area === 'session' && ch.health) loadConns();
});
setInterval(() => { if (!$('#pane-block').hidden) refreshBlock(); }, 4000);
setInterval(() => { if (CONN.list.length && Object.keys(CONN.health).length) renderModels(); }, 30000);
(async () => {
  const { settings } = await chrome.storage.local.get('settings');
  S = { ...DEFAULTS, ...(settings || {}) };
  buildGallery(); setLangUI();
  await loadConns();
  if (!S.uiLang) openLangPick(); else if (!S.seenGuide) openGuide();
  await load();
  requestAnimationFrame(frame);
})();
