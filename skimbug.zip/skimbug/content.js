// Skimbug content script: reads the page locally (article vs side boxes vs clutter),
// collects links, tracks what's on screen, runs Clean page and the crawler.
// Nothing here talks to any server; the side panel asks for a snapshot when it needs one.
(() => {
'use strict';
if (window.__skimbug) return; window.__skimbug = true;
if (window.top !== window && innerWidth < 300) return;
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const inUI = el => !!(el && el.closest && el.closest('[data-sb-ui]'));
const HOST = location.host;
const textOf = el => (el.textContent || '').replace(/\s+/g, ' ').trim();
const REDUCE = matchMedia('(prefers-reduced-motion: reduce)').matches;

let S = { crawler: true, crawlerKind: 'random', crawlerPal: 'random', hlMode: 'pos', followMouse: false, follow: true };
chrome.storage.local.get('settings').then(({ settings }) => { if (settings) S = { ...S, ...settings }; boot(); });
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local' || !ch.settings) return;
  const prev = S; S = { ...S, ...ch.settings.newValue };
  if (prev.crawler !== S.crawler || prev.crawlerKind !== S.crawlerKind || prev.crawlerPal !== S.crawlerPal) respawn();
  if (prev.hlMode !== S.hlMode && S.hlMode === 'pos') ensureNlp();
  if (prev.uiLang !== S.uiLang && showMap) renderOverlay();
});

/* ================= page reader ================= */
const AD_HINT = '[id^="div-gpt-ad"],[id^="google_ads"],.adsbygoogle,[data-ad-unit],[data-ad-slot],[class*="ad-slot"],[class*="advert" i],[id*="taboola"],[id*="outbrain"],[class*="sponsored" i]';
const JUNK_RE = /(^|[\s_-])(nav|navigation|navbar|menu|masthead|header|footer|breadcrumbs?|share|sharing|social|login|signin|account|subscribe|newsletter|cookie|consent|toolbar|ticker|skip|legal|copyright|topics|tags)([\s_-]|$)/i;
const SIDE_RE = /(^|[\s_-])(related|most|read|popular|trending|recommended|more|from|top-stories|sidebar|aside|also|explore|widget)([\s_-]|$)/i;
const hintOf = el => `${el.id || ''} ${typeof el.className === 'string' ? el.className : ''} ${el.getAttribute('role') || ''} ${el.getAttribute('aria-label') || ''}`;
const visible = el => { const r = el.getBoundingClientRect(); return r.width > 2 && r.height > 2; };
function linkStats(el) { const t = textOf(el).length || 1; let lt = 0, words = 0, n = 0; for (const a of el.querySelectorAll('a')) { const s = textOf(a); lt += s.length; words += s.split(' ').filter(Boolean).length; n++; } return { density: lt / t, avgWords: n ? words / n : 0 }; }
function labelFor(el, type) {
  const tag = el.tagName.toLowerCase(), hint = hintOf(el);
  if (/cookie|consent/i.test(hint)) return 'Cookie banner';
  if (type === 'ad') return 'Ad';
  if (tag === 'header' || /masthead/.test(hint)) return 'Site header';
  if (tag === 'nav') return 'Menu';
  if (tag === 'footer') return 'Footer';
  if (/share|social/i.test(hint)) return 'Share buttons';
  if (/newsletter|subscribe/i.test(hint)) return 'Newsletter sign-up';
  const h = el.querySelector('h2,h3,h4');
  if (type !== 'main' && h && textOf(h).length && textOf(h).length < 40) return textOf(h);
  return type === 'side' ? 'Side box' : 'Page furniture';
}
let P = null;
function classify() {
  const t0 = performance.now(), root = document.body;
  const scores = new Map();
  for (const p of root.querySelectorAll('p, article div, [role="main"] div')) {
    if (p.tagName !== 'P' && p.children.length) continue;
    const t = textOf(p); if (t.length < 80 || inUI(p)) continue;
    const s = 1 + (t.match(/,/g) || []).length * .5 + Math.min(t.length / 100, 3);
    let el = p.parentElement, k = 1;
    for (let d = 0; d < 3 && el && el !== root; d++, el = el.parentElement, k /= 2) scores.set(el, (scores.get(el) || 0) + s * k);
  }
  let best = null, bs = -1;
  for (const [el, s] of scores) {
    const h = hintOf(el); let v = s * (1 - Math.min(linkStats(el).density, .9));
    if (/article|story|content|body|main|post|entry/i.test(h) || el.tagName === 'ARTICLE' || el.tagName === 'MAIN') v *= 1.4;
    if (/comment|sidebar|related|footer|promo|sponsor/i.test(h)) v *= .2;
    if (v > bs) { bs = v; best = el; }
  }
  const main = best ? (best.closest('article') || best) : root;
  const regions = [];
  const push = (el, type) => regions.push({ el, type, label: labelFor(el, type), chars: textOf(el).length });
  function region(el, depth) {
    if (inUI(el) || el.matches('script,style,noscript,template,link,meta,svg') || !visible(el)) return;
    if (el.matches(AD_HINT)) return push(el, 'ad');
    const tag = el.tagName.toLowerCase(), h = hintOf(el), role = el.getAttribute('role') || '';
    if (['nav', 'header', 'footer', 'form'].includes(tag) || /^(navigation|banner|contentinfo|search)$/.test(role) || JUNK_RE.test(h)) return push(el, 'junk');
    const kids = [...el.children].filter(c => !inUI(c) && !c.matches('script,style,noscript,template'));
    if (kids.length > 1 && depth < 4 && (el.querySelector(AD_HINT) || !SIDE_RE.test(h))) { kids.forEach(c => region(c, depth + 1)); return; }
    const t = textOf(el); if (!t) return;
    if (SIDE_RE.test(h) || tag === 'aside') return push(el, 'side');
    const st = linkStats(el);
    if (st.density > .5) return push(el, st.avgWords >= 4 ? 'side' : 'junk');
    if (t.length < 60) return push(el, 'junk');
    push(el, 'side');
  }
  if (main !== root) (function walk(el) { for (const c of [...el.children]) { if (inUI(c) || c === main) continue; if (c.contains(main)) walk(c); else region(c, 0); } })(root);
  const inner = [];
  for (const el of main.querySelectorAll('aside, nav, [class*="share" i], [class*="related" i], [class*="newsletter" i], ' + AD_HINT)) {
    if (inUI(el) || inner.some(x => x.el.contains(el)) || !visible(el)) continue;
    const type = el.matches(AD_HINT) ? 'ad' : (/share|social/i.test(hintOf(el)) || el.tagName === 'NAV') ? 'junk' : 'side';
    inner.push({ el, type, label: labelFor(el, type), chars: textOf(el).length });
  }
  const excluded = inner.map(x => x.el);
  const paras = [...main.querySelectorAll('h1, h2, h3, p, blockquote, li')]
    .filter(el => !inUI(el) && !excluded.some(x => x.contains(el)) && textOf(el).length > (el.tagName === 'LI' ? 40 : 0) && visible(el))
    .filter(el => !(el.tagName === 'P' && el.closest('li, blockquote')) && !(el.tagName === 'LI' && el.querySelector('p')));
  const mainChars = paras.reduce((a, el) => a + textOf(el).length, 0);
  const words = paras.reduce((a, el) => a + textOf(el).split(' ').length, 0);
  const all = [{ el: main, type: 'main', label: 'Article', chars: mainChars }, ...regions, ...inner];
  P = { main, paras, all, typeMap: new Map(all.map(x => [x.el, x])), inner, words, kind: mainChars > 1200 && paras.length >= 4 ? 'Article' : 'Front page or feed', ms: performance.now() - t0 };
  return P;
}
function regionOf(el) {
  for (let e = el; e && e !== document.body; e = e.parentElement) { const x = P.typeMap.get(e); if (x && x.type !== 'main') return x; if (e === P.main) return P.typeMap.get(e); }
  return null;
}
let LINKS = [], SIDE = [];
function collectLinks() {
  const seen = new Set(), dropped = {}; LINKS = []; SIDE = [];
  const drop = k => dropped[k] = (dropped[k] || 0) + 1;
  let order = 0;
  for (const a of document.querySelectorAll('a[href]')) {
    if (inUI(a)) continue;
    const href = a.getAttribute('href');
    if (!href || href.startsWith('#') || /^(javascript|mailto|tel):/i.test(href)) { drop('Page anchors'); continue; }
    if (!visible(a)) { drop('Hidden'); continue; }
    const reg = regionOf(a); if (!reg) { drop('Outside the article'); continue; }
    if (reg.type === 'ad') { drop('Ads'); continue; }
    if (reg.type === 'junk') { drop(reg.label === 'Menu' || reg.label === 'Site header' ? 'Menus and header' : reg.label); continue; }
    let url; try { url = new URL(href, location.href); } catch (e) { continue; }
    if (!/^https?:$/.test(url.protocol)) continue;
    const key = url.href.replace(/[#?].*$/, '');
    if (seen.has(key) || key === location.href.replace(/[#?].*$/, '')) { drop('Repeats'); continue; }
    seen.add(key);
    const text = textOf(a) || a.getAttribute('aria-label') || a.title || url.pathname;
    const inInner = P.inner.find(x => x.el.contains(a));
    const group = inInner ? 'related' : reg.type === 'side' ? 'side' : url.host !== HOST ? 'source' : 'related';
    const ctx = textOf(a.closest('p,li,blockquote') || a.parentElement).slice(0, 160);
    let score = group === 'source' ? 5 : group === 'related' ? 3 : 1;
    if (text.split(' ').length >= 2) score += 1;
    if (group !== 'side' && a.closest('p, blockquote, li') && P.paras.some(p => p.contains(a))) score += 3;
    score += Math.max(0, 2 - order / 10);
    const item = { a, url: url.href, host: url.host, text: text.slice(0, 140), ctx, group, block: inInner ? inInner.label : reg.label, score, order: order++ };
    (group === 'side' ? SIDE : LINKS).push(item);
  }
  LINKS.forEach((l, i) => l.id = 'L' + (i + 1));
  SIDE.forEach((l, i) => l.id = 'S' + (i + 1));
  return dropped;
}
function visibleParas() {
  const H = innerHeight, out = [];
  P.paras.forEach((el, i) => { const r = el.getBoundingClientRect(); if (!r.height) return; const vis = Math.min(r.bottom, H) - Math.max(r.top, 0); if (vis > Math.min(r.height * .4, 60)) out.push(i); });
  return out;
}
const MAP = { y0: 0, y1: 1 };
function stripData() {
  const blocks = [];
  for (const x of P.all) {
    const r = x.el.getBoundingClientRect();
    if (r.height < 2 || getComputedStyle(x.el).position === 'fixed') continue;
    blocks.push({ type: x.type, label: x.label, top: r.top + scrollY, bottom: r.bottom + scrollY });
  }
  if (!blocks.length) return { segs: [] };
  MAP.y0 = Math.min(...blocks.map(b => b.top)); MAP.y1 = Math.max(...blocks.map(b => b.bottom));
  const span = Math.max(1, MAP.y1 - MAP.y0);
  return { segs: blocks.map(b => ({ type: b.type, label: b.label, a: (b.top - MAP.y0) / span, b: (b.bottom - MAP.y0) / span })) };
}
function viewData() {
  const span = Math.max(1, MAP.y1 - MAP.y0);
  return { a: (scrollY - MAP.y0) / span, b: (scrollY + innerHeight - MAP.y0) / span };
}
function snapshot() {
  classify();
  const dropped = collectLinks();
  const cnt = { main: 0, side: 0, junk: 0, ad: 0 }; for (const x of P.all) cnt[x.type]++;
  const h1 = P.main.querySelector('h1') || document.querySelector('h1');
  return {
    url: location.href, host: HOST, title: (h1 && textOf(h1)) || document.title, kind: P.kind, words: P.words, ms: P.ms,
    paras: P.paras.map(el => ({ text: textOf(el).slice(0, 4000), head: /^H\d/.test(el.tagName) })),
    visible: visibleParas(), counts: cnt, dropped,
    links: LINKS.map(({ a, ...l }) => l), side: SIDE.map(({ a, ...l }) => l),
    strip: stripData(), view: viewData(),
    sensitive: !!document.querySelector('input[type=password], [autocomplete^="cc-"]'),
    lang: (document.documentElement.lang || '').slice(0, 2).toLowerCase(),
  };
}

/* ================= overlays, find, clean page ================= */
const COL = { main: '#00E5FF', side: '#FF2BD6', junk: '#5B6B84', ad: '#FF3B5C' };
const NAME = { main: 'Article', side: 'Side box', junk: 'Clutter', ad: 'Ad' };
// the few words Skimbug writes onto pages, in the interface language
const CRU = { 'Article': 'Статья', 'Side box': 'Боковой блок', 'Clutter': 'Лишнее', 'Ad': 'Реклама', 'Cookie banner': 'Баннер cookie', 'Site header': 'Шапка сайта', 'Menu': 'Меню', 'Footer': 'Подвал', 'Share buttons': 'Кнопки «Поделиться»', 'Newsletter sign-up': 'Подписка на рассылку', 'Page furniture': 'Служебный блок',
  'Removed by Skimbug: cookie banner': 'Убрано Skimbug: баннер cookie', 'Removed by Skimbug, rule': 'Убрано Skimbug, правило' };
const tr = s => S.uiLang === 'ru' && CRU[s] || s;
let overlay = null, showMap = false;
function renderOverlay() {
  if (!showMap) { if (overlay) overlay.remove(); overlay = null; return; }
  if (!P) classify();
  if (!overlay) { overlay = document.createElement('div'); overlay.setAttribute('data-sb-ui', ''); overlay.className = 'sb-overlay'; document.documentElement.appendChild(overlay); }
  overlay.innerHTML = '';
  for (const x of P.all) {
    const r = x.el.getBoundingClientRect(); if (r.width < 4 || r.height < 4) continue;
    const fixed = getComputedStyle(x.el).position === 'fixed';
    const d = document.createElement('div'); d.className = 'sb-box';
    d.style.cssText = `--c:${COL[x.type]};left:${r.left + (fixed ? 0 : scrollX)}px;top:${r.top + (fixed ? 0 : scrollY)}px;width:${r.width}px;height:${r.height}px;${fixed ? 'position:fixed;' : ''}`;
    const s = document.createElement('span'); s.textContent = x.type === 'main' ? tr(NAME.main) : `${tr(NAME[x.type])}: ${tr(x.label)}`;
    if (r.top + (fixed ? 0 : scrollY) < 20) d.classList.add('sb-in'); d.appendChild(s); overlay.appendChild(d);
  }
}
function findLink(id) {
  const l = [...LINKS, ...SIDE].find(x => x.id === id); if (!l) return false;
  l.a.scrollIntoView({ behavior: REDUCE ? 'auto' : 'smooth', block: 'center' });
  l.a.classList.remove('sb-flash'); void l.a.offsetWidth; l.a.classList.add('sb-flash');
  return true;
}
function findLogo() {
  const hdr = (P.all.find(x => x.label === 'Site header') || {}).el || document.querySelector('header');
  if (!hdr) return null;
  return hdr.querySelector('[class*="logo" i], a[rel="home"], img[alt*="logo" i]')
    || [...hdr.querySelectorAll('a[href]')].find(a => { try { return new URL(a.href).pathname === '/'; } catch (e) { return false; } }) || null;
}
let focusMode = 'off';
function applyFocus(mode) {
  focusMode = mode;
  $$('[data-sb-focus],[data-sb-focus-collapse],[data-sb-focus-main]').forEach(el => { el.removeAttribute('data-sb-focus'); el.removeAttribute('data-sb-focus-collapse'); el.removeAttribute('data-sb-focus-main'); });
  if (mode !== 'off') {
    classify();
    const logo = findLogo();
    for (const x of P.all) {
      if (x.type === 'main') continue;
      if (logo && x.el.contains(logo)) { for (let e = logo; e && e !== x.el; e = e.parentElement) for (const sib of e.parentElement.children) if (sib !== e && !sib.contains(logo)) sib.setAttribute('data-sb-focus', mode); continue; }
      x.el.setAttribute('data-sb-focus', mode);
    }
    if (mode === 'hide') {
      P.main.setAttribute('data-sb-focus-main', '');
      for (let e = P.main.parentElement; e && e !== document.body; e = e.parentElement) if (/grid|flex/.test(getComputedStyle(e).display)) e.setAttribute('data-sb-focus-collapse', '');
    }
  }
  requestAnimationFrame(() => { crawlMeasure(); renderOverlay(); sendView(true); });
}
/* blocker: count and reveal what the cosmetic filters hid */
let selectors = null, peeked = [];
async function cosmeticHits() {
  if (!selectors) selectors = await chrome.runtime.sendMessage({ type: 'selectors' });
  const found = new Map();
  for (const [list, arr] of Object.entries(selectors)) {
    for (let i = 0; i < arr.length; i += 300) {
      const chunk = arr.slice(i, i + 300);
      let els; try { els = document.querySelectorAll(chunk.join(',')); } catch (e) { continue; }
      for (const el of els) if (!found.has(el) && !inUI(el)) {
        const sel = chunk.find(s => { try { return el.matches(s); } catch (e) { return false; } });
        found.set(el, { list, sel });
      }
    }
  }
  for (const el of document.querySelectorAll('[data-sb-cookie]')) if (!found.has(el)) found.set(el, { list: 'annoyances', sel: COOKIE_SEL });
  return found;
}
/* cookie banners the lists miss: a fixed box that talks about cookies and has an Accept button */
const COOKIE_RE = /\b(cookies?|consent|gdpr|ccpa)\b|cookie|куки|файл(?:ы|ов) cookie/i;
const ACCEPT_RE = /^(accept|accept all|accept cookies|accept all cookies|allow|allow all|allow cookies|agree|i agree|agree and close|got it|ok|okay|continue|принять|принять все|согласен|согласна|хорошо|понятно|ok, понятно)[.!]?$/i;
const COOKIE_SEL = 'Skimbug: cookie banner with an Accept button';
function cookieBanners() {
  if (!S.block || (S.lists && S.lists.annoyances === false) || (S.paused || []).some(h => HOST === h || HOST.endsWith('.' + h))) return 0;
  const cand = new Set(document.querySelectorAll('[id*="cookie" i],[class*="cookie" i],[id*="consent" i],[class*="consent" i],[aria-label*="cookie" i],[role="dialog"],[aria-modal="true"]'));
  for (const c of document.body.children) { cand.add(c); for (const k of c.children) cand.add(k); }
  let n = 0;
  for (const el of cand) {
    if (inUI(el) || el === document.body || (P && el.contains(P.main))) continue;
    // climb to the fixed or sticky box that holds it
    let box = null;
    for (let e = el; e && e !== document.body; e = e.parentElement) { const p = getComputedStyle(e).position; if (p === 'fixed' || p === 'sticky') { box = e; break; } }
    if (!box || box.hasAttribute('data-sb-cookie') || inUI(box) || (P && box.contains(P.main))) continue;
    const t = textOf(box); if (t.length < 20 || t.length > 2500 || !COOKIE_RE.test(t)) continue;
    const r = box.getBoundingClientRect(); if (r.width * r.height > innerWidth * innerHeight * .85 && !/cookie|consent/i.test(hintOf(box))) continue;
    const btn = [...box.querySelectorAll('button, a, [role="button"], input[type="button"], input[type="submit"]')].some(b => ACCEPT_RE.test((textOf(b) || b.value || '').trim()));
    if (!btn) continue;
    box.setAttribute('data-sb-cookie', ''); n++;
  }
  if (n) for (const e of [document.documentElement, document.body]) if (getComputedStyle(e).overflowY === 'hidden') e.style.setProperty('overflow', 'auto', 'important');
  return n;
}
async function blockInfo() {
  const hits = await cosmeticHits();
  const by = {}; const rules = {}; let total = 0;
  // count only the outermost removed block, not the label inside it
  for (const [el, { list, sel }] of hits) {
    let inner = false; for (let p = el.parentElement; p; p = p.parentElement) if (hits.has(p)) { inner = true; break; }
    if (inner) continue;
    total++; by[list] = (by[list] || 0) + 1; rules[sel] = rules[sel] || { list, n: 0 }; rules[sel].n++;
  }
  return { total, by, rules: Object.entries(rules).sort((a, b) => b[1].n - a[1].n).slice(0, 12).map(([sel, v]) => ({ sel, ...v })) };
}
async function peek(on) {
  // our cosmetic CSS ends every selector with :not([data-sb-peek]), so marking an element gives it back its own styles
  peeked.forEach(el => { el.removeAttribute('data-sb-peek'); el.classList.remove('sb-peeked'); if (el.dataset.sbTitle != null) { el.dataset.sbTitle ? el.setAttribute('title', el.dataset.sbTitle) : el.removeAttribute('title'); delete el.dataset.sbTitle; } });
  peeked = [];
  if (!on) return;
  const hits = await cosmeticHits();
  for (const [el, { sel }] of hits) {
    el.setAttribute('data-sb-peek', ''); el.classList.add('sb-peeked');
    el.dataset.sbTitle = el.getAttribute('title') || ''; el.setAttribute('title', sel === COOKIE_SEL ? tr('Removed by Skimbug: cookie banner') : tr('Removed by Skimbug, rule') + ' ##' + sel);
    peeked.push(el);
  }
}

/* ================= messages from the side panel ================= */
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.to !== 'page') return false;
  (async () => {
    switch (msg.type) {
      case 'snapshot': return snapshot();
      case 'find': return { ok: findLink(msg.id) };
      case 'outline': showMap = !!msg.on; renderOverlay(); return { ok: true };
      case 'focus': applyFocus(msg.mode); return { ok: true, mode: focusMode };
      case 'state': return { focus: focusMode, outline: showMap, peek: peeked.length > 0 };
      case 'blockInfo': return blockInfo();
      case 'peek': await peek(msg.on); return { ok: true, n: peeked.length };
      case 'scrollTo': scrollTo({ top: MAP.y0 + msg.f * (MAP.y1 - MAP.y0) - innerHeight / 2, behavior: REDUCE ? 'auto' : 'smooth' }); return { ok: true };
      case 'followWords': crawlerFollow(msg.text || ''); return { ok: true };
      default: return { error: 'unknown' };
    }
  })().then(reply, e => reply({ error: String(e) }));
  return true;
});
let vt = 0;
function sendView(force) {
  if (!P) return;
  clearTimeout(vt);
  vt = setTimeout(() => { try { chrome.runtime.sendMessage({ to: 'panel', type: 'view', url: location.href, view: viewData(), visible: visibleParas() }).catch(() => {}); } catch (e) {} }, force ? 0 : 120);
}
addEventListener('scroll', () => sendView(), { passive: true });
addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { sizeCanvas(); crawlMeasure(); renderOverlay(); }, 150); });
let rt = 0;

/* ================= word types ================= */
const POS = { noun: '#00E5FF', verb: '#FF2BD6', adj: '#FFB020', adv: '#7CFF6B', name: '#A98BFF', num: '#FF7A45', other: '#8FA3BF' };
const STOP_EN = new Set('the a an and or but nor of to in on at by for with from as into onto over under after before about than then so if not no its it this that these those which who whom whose what when where why how there their they them he she his her him we our us you your i me my one each every all some any both either other such own same just only very also more most much many few up down out off again further once here'.split(' '));
const VERB_EN = new Set('is are was were be been being am has have had do does did can could will would should may might must said says say get gets got go goes went make makes made keep keeps kept take takes took give gives come comes came see seen know known think'.split(' '));
const STOP_RU = new Set('и в во не на с со что как а но или из за по к ко у о об от до для при без над под это этот эта эти тот та те он она оно они его её их мы вы я ты же ли бы то так уже ещё еще только даже где когда который которая которые чтобы если'.split(' '));
function guessPos(raw, start) {
  const s = raw.replace(/[^\p{L}\p{N}'.,-]/gu, '').replace(/[.,]+$/, ''), l = s.toLowerCase();
  if (!s) return 'other';
  if (/\d/.test(s)) return 'num';
  if (/[а-яё]/i.test(s)) {
    if (STOP_RU.has(l)) return 'other';
    if (!start && /^[А-ЯЁ]/.test(s)) return 'name';
    if (l.length > 3 && /(ть|ться|ти|чь|ал|ял|ил|ел|ла|ли|ло|лся|лась|лись|ет|ёт|ит|ют|ут|ат|ят|ешь|ишь)$/.test(l)) return 'verb';
    if (/(ый|ий|ой|ая|яя|ое|ее|ые|ие|ого|его|ому|ему|ую|юю|ым|ими|ыми|ых|их)$/.test(l)) return 'adj';
    return 'noun';
  }
  if (STOP_EN.has(l)) return 'other';
  if (VERB_EN.has(l)) return 'verb';
  if (!start && /^[A-Z]/.test(s)) return 'name';
  if (l.length > 4 && /ly$/.test(l)) return 'adv';
  if (/(ing|ed|ize|ise|ify|ates)$/.test(l)) return 'verb';
  if (/(ous|ful|ive|able|ible|ical|less|ish|ary|est)$/.test(l)) return 'adj';
  return 'noun';
}
const normW = s => s.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
function posOfTags(tags) {
  const t = new Set(tags);
  if (t.has('Value') || t.has('Cardinal') || t.has('NumericValue') || t.has('Unit')) return 'num';
  if (t.has('ProperNoun') || t.has('Person') || t.has('Place') || t.has('Organization')) return 'name';
  if (t.has('Verb') || t.has('Copula') || t.has('Auxiliary') || t.has('Modal')) return 'verb';
  if (t.has('Adjective')) return 'adj';
  if (t.has('Adverb')) return 'adv';
  if (t.has('Noun')) return 'noun';
  return 'other';
}
let nlpAsked = false;
async function ensureNlp() {
  if (typeof window.nlp === 'function') return tagWithNlp();
  if (nlpAsked || !words.length) return;
  const sample = words.slice(0, 200).map(w => w.text).join(' ');
  if (/[а-яё]/i.test(sample)) return; // the grammar library is English-only
  nlpAsked = true;
  const r = await chrome.runtime.sendMessage({ type: 'injectNlp' }).catch(() => null);
  if (r && r.ok) tagWithNlp();
}
function tagWithNlp() {
  if (typeof window.nlp !== 'function') return;
  const byPara = new Map(); for (const w of words) { if (!byPara.has(w.p)) byPara.set(w.p, []); byPara.get(w.p).push(w); }
  for (const list of byPara.values()) {
    const text = list.map(w => w.el.textContent).join(' ');
    if (/[а-яё]/i.test(text)) continue;
    let terms = [];
    try { terms = window.nlp(text).json().flatMap(s => s.terms || []); } catch (e) { continue; }
    let j = 0;
    for (const w of list) {
      const key = normW(w.el.textContent); if (!key) continue;
      for (let k = j; k < Math.min(terms.length, j + 4); k++) { const tn = normW(terms[k].text || ''); if (tn && key.includes(tn)) { w.pos = posOfTags(terms[k].tags || []); j = k + 1; break; } }
    }
  }
}

/* ================= crawler (engine in crawler.js) ================= */
const { env, Crawler, KINDS, PALS, A, rnd, pick, TAU, HP } = self.SBC;
const fxs = env.fxs;
const words = env.words;
Object.defineProperty(env, 'S', { get: () => S, configurable: true });
let wrapped = false;
function wrapWords() {
  if (wrapped) return; wrapped = true;
  if (!P) classify();
  let pi = -1;
  for (const el of P.paras) {
    if (/^H\d/.test(el.tagName) || el.isContentEditable) continue;
    pi++; let start = true;
    const tw = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, { acceptNode: n => n.nodeValue.trim() && !n.parentElement.closest('script,style,textarea,input,[contenteditable]') ? 1 : 2 });
    const nodes = []; while (tw.nextNode()) nodes.push(tw.currentNode);
    for (const tn of nodes) {
      const frag = document.createDocumentFragment();
      for (const part of tn.nodeValue.split(/(\s+)/)) {
        if (!part) continue;
        if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(part)); continue; }
        const s = document.createElement('span'); s.className = 'sbw'; s.textContent = part; frag.appendChild(s);
        const clean = part.replace(/[^\p{L}\p{N}-]/gu, '');
        words.push({ el: s, text: clean.toLowerCase(), len: clean.length, x: 0, y: 0, w: 0, h: 0, cx: 0, cy: 0, busy: 0, hlUntil: 0, pri: false, p: pi, pos: guessPos(part, start) });
        start = /[.!?]["”’')]*$/.test(part);
      }
      tn.parentNode.replaceChild(frag, tn);
    }
  }
}
function crawlMeasure() { for (const w of words) { const r = w.el.getBoundingClientRect(); w.x = r.left + scrollX; w.y = r.top + scrollY; w.w = r.width; w.h = r.height; w.cx = w.x + w.w / 2; w.cy = w.y + w.h / 2; } }
function crawlerFollow(text) {
  const stems = new Set(text.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(s => s.length >= 5).map(s => s.slice(0, 5)));
  for (const w of words) w.pri = w.len >= 5 && stems.has(w.text.slice(0, 5));
}
function markWord(w, col, now) {
  if (S.hlMode === 'pos') col = POS[w.pos || 'other'];
  const until = now + 30000; w.hlUntil = until; w.el.style.setProperty('--sbc', col);
  w.el.classList.remove('sbhl'); w.el.classList.add('sbhit');
  setTimeout(() => { w.el.classList.remove('sbhit'); w.el.classList.add('sbhl'); }, 240);
  setTimeout(() => { if (w.hlUntil === until) w.el.classList.remove('sbhl'); }, 30000);
}
let canvas = null, cx = null, dpr = 1, crawler = null, last = performance.now(), raf = 0;
const mouse = env.mouse; Object.assign(mouse, { cx: 0, cy: 0, t: 0 });
env.markWord = markWord;
addEventListener('pointermove', e => {
  if (e.pointerType !== 'mouse') return;
  const now = performance.now(), dtm = (now - mouse.t) / 1000;
  if (mouse.on && dtm > 0 && dtm < .2) { const inst = Math.hypot(e.clientX - mouse.cx, e.clientY - mouse.cy) / dtm; mouse.speed += (Math.min(inst, 1500) - mouse.speed) * .45; }
  mouse.on = true; mouse.cx = e.clientX; mouse.cy = e.clientY; mouse.t = now;
}, { passive: true });
document.addEventListener('mouseout', e => { if (!e.relatedTarget) mouse.on = false; });
function sizeCanvas() { if (!canvas) return; dpr = Math.min(2, devicePixelRatio || 1); canvas.width = Math.round(innerWidth * dpr); canvas.height = Math.round(innerHeight * dpr); }
function respawn() {
  if (crawler) { crawler.release(); crawler = null; }
  if (!S.crawler || !words.length) { if (canvas) canvas.hidden = true; return; }
  if (!canvas) { canvas = document.createElement('canvas'); canvas.className = 'sb-crawl'; canvas.setAttribute('data-sb-ui', ''); canvas.setAttribute('aria-hidden', 'true'); document.documentElement.appendChild(canvas); sizeCanvas(); }
  canvas.hidden = false;
  const kind = KINDS[S.crawlerKind] ? S.crawlerKind : pick(Object.keys(KINDS));
  crawler = new Crawler(kind, scrollX + innerWidth * rnd(.2, .6), scrollY + innerHeight * rnd(.3, .6), rnd(0, TAU), S.crawlerPal);
  const t0 = performance.now(); for (let s = 0; s < 30; s++) crawler.update(1 / 60, t0);
  if (!raf) raf = requestAnimationFrame(frame);
}
function frame(now) {
  raf = 0;
  if (!crawler || document.hidden) { if (crawler) raf = requestAnimationFrame(frame); return; }
  const dt = Math.min(.04, (now - last) / 1000); last = now;
  if (mouse.on) { mouse.x = mouse.cx + scrollX; mouse.y = mouse.cy + scrollY; }
  mouse.speed *= Math.exp(-dt * 4);
  if (!REDUCE) crawler.update(dt, now);
  for (let i = fxs.length - 1; i >= 0; i--) { const f = fxs[i]; f.r += dt * 40; f.a -= dt * 3; if (f.a <= 0) fxs.splice(i, 1); }
  cx = cx || canvas.getContext('2d');
  cx.setTransform(1, 0, 0, 1, 0, 0); cx.clearRect(0, 0, canvas.width, canvas.height);
  cx.setTransform(dpr, 0, 0, dpr, -scrollX * dpr, -scrollY * dpr);
  cx.lineCap = 'square'; cx.lineJoin = 'miter';
  crawler.draw(cx);
  for (const f of fxs) { cx.strokeStyle = A(f.col, f.a); cx.lineWidth = 1; cx.strokeRect(f.x - f.w / 2 - f.r - 3, f.y - f.h / 2 - f.r - 2, f.w + f.r * 2 + 6, f.h + f.r * 2 + 4); }
  raf = requestAnimationFrame(frame);
}

/* ================= boot ================= */
function boot() {
  // wait for the page to settle so we don't fight its own scripts
  const go = () => {
    classify();
    cookieBanners(); setTimeout(cookieBanners, 2500); setTimeout(cookieBanners, 6000);
    if (P.kind === 'Article' && S.crawler) {
      wrapWords(); crawlMeasure(); respawn();
      if (S.hlMode === 'pos') ensureNlp();
      if (document.fonts && document.fonts.ready) document.fonts.ready.then(crawlMeasure);
      setInterval(() => { if (crawler) crawlMeasure(); }, 4000);
    }
  };
  if ('requestIdleCallback' in window) requestIdleCallback(() => setTimeout(go, 600), { timeout: 3000 }); else setTimeout(go, 1500);
}
})();
