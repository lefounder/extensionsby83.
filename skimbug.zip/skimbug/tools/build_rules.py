#!/usr/bin/env python3
"""Convert EasyList-format filter lists into Chrome declarativeNetRequest rulesets
and generic cosmetic CSS for Skimbug.

Network rules: plain-domain rules (||example.com^) are grouped into a few rules with
requestDomains, so 40k+ ad-server domains cost only a handful of DNR rules. Other URL
patterns become one urlFilter rule each. Anything using options DNR can't express
(redirect, csp, removeparam, popup, ...) is skipped.

Cosmetic rules: only generic ##selector lines (no domain) are kept, one CSS rule per
selector so a single bad selector can't disable the rest.
"""
import json, re, sys, pathlib

HERE = pathlib.Path(__file__).parent
LISTS = HERE / 'lists'
OUT = HERE.parent / 'rules'

RT = {  # ABP resource type -> DNR resource type
    'script': 'script', 'image': 'image', 'stylesheet': 'stylesheet', 'object': 'object',
    'xmlhttprequest': 'xmlhttprequest', 'subdocument': 'sub_frame', 'ping': 'ping',
    'media': 'media', 'font': 'font', 'websocket': 'websocket', 'other': 'other',
}
ALL_RT = ['script', 'image', 'stylesheet', 'object', 'xmlhttprequest', 'sub_frame', 'ping', 'media', 'font', 'websocket', 'other']
UNSUPPORTED = {'redirect', 'redirect-rule', 'csp', 'removeparam', 'rewrite', 'popup', 'popunder', 'document', 'doc',
               'elemhide', 'ehide', 'generichide', 'ghide', 'genericblock', 'badfilter', 'denyallow', 'header',
               'permissions', 'replace', 'urltransform', 'uritransform', 'cookie', 'to', 'method', 'all', 'webrtc',
               'specifichide', 'shide', 'inline-script', 'inline-font', 'empty', 'mp4', 'strict1p', 'strict3p'}
DOMAIN_ONLY = re.compile(r'^\|\|([a-z0-9][a-z0-9.-]*[a-z0-9])\^$')


def parse_options(opts):
    """Return dict of DNR condition pieces, or None if the rule can't be expressed."""
    cond = {}
    inc, exc = [], []
    for o in opts.split(','):
        o = o.strip()
        if not o:
            continue
        neg = o.startswith('~')
        name = o[1:] if neg else o
        key, _, val = name.partition('=')
        key = key.lower()
        if key in ('third-party', '3p'):
            cond['domainType'] = 'firstParty' if neg else 'thirdParty'
        elif key in ('first-party', '1p'):
            cond['domainType'] = 'thirdParty' if neg else 'firstParty'
        elif key in RT:
            (exc if neg else inc).append(RT[key])
        elif key == 'domain':
            doms = val.split('|')
            yes = [d for d in doms if d and not d.startswith('~')]
            no = [d[1:] for d in doms if d.startswith('~')]
            if any('*' in d or '/' in d for d in yes + no):
                return None
            if yes:
                cond['initiatorDomains'] = yes
            if no:
                cond['excludedInitiatorDomains'] = no
        elif key in ('match-case',):
            cond['isUrlFilterCaseSensitive'] = True
        elif key in ('important',):
            cond['_important'] = True
        else:
            return None  # unsupported or unknown option
    if inc:
        cond['resourceTypes'] = sorted(set(inc))
    elif exc:
        rest = [t for t in ALL_RT if t not in exc]
        if not rest:
            return None
        cond['resourceTypes'] = rest
    return cond


def convert(files, id_start=1):
    groups = {}   # signature -> {'action','cond','domains':[]}
    singles = []
    seen = set()
    for f in files:
        for raw in (LISTS / f).read_text(encoding='utf-8', errors='ignore').splitlines():
            line = raw.strip()
            if not line or line.startswith('!') or line.startswith('['):
                continue
            if '##' in line or '#@#' in line or '#?#' in line or '#$#' in line or '#%#' in line:
                continue
            allow = line.startswith('@@')
            if allow:
                line = line[2:]
            pattern, opts = line, ''
            if '$' in line and not line.startswith('/'):
                pattern, _, opts = line.rpartition('$')
            if pattern.startswith('/') and pattern.endswith('/') and len(pattern) > 1:
                continue  # regex rules skipped
            cond = parse_options(opts) if opts else {}
            if cond is None:
                continue
            if not pattern.isascii() or len(pattern) < 4 or pattern.startswith('||*') or ' ' in pattern:
                continue
            important = cond.pop('_important', False)
            action = 'allow' if allow else 'block'
            priority = 3 if allow else (2 if important else 1)
            key = (action, pattern, json.dumps(cond, sort_keys=True))
            if key in seen:
                continue
            seen.add(key)
            m = DOMAIN_ONLY.match(pattern)
            if m:
                sig = (action, priority, json.dumps(cond, sort_keys=True))
                g = groups.setdefault(sig, {'action': action, 'priority': priority, 'cond': cond, 'domains': []})
                g['domains'].append(m.group(1))
            else:
                c = dict(cond)
                c['urlFilter'] = pattern
                singles.append({'priority': priority, 'action': {'type': action}, 'condition': c})
    rules, rid = [], id_start
    for g in groups.values():
        doms = sorted(set(g['domains']))
        for i in range(0, len(doms), 1000):
            c = dict(g['cond'])
            c['requestDomains'] = doms[i:i + 1000]
            rules.append({'id': rid, 'priority': g['priority'], 'action': {'type': g['action']}, 'condition': c}); rid += 1
    for r in singles:
        r['id'] = rid; rid += 1
        rules.append(r)
    return rules


def cosmetic(files):
    sels = []
    seen = set()
    for f in files:
        for raw in (LISTS / f).read_text(encoding='utf-8', errors='ignore').splitlines():
            line = raw.strip()
            if not line.startswith('##'):
                continue  # only generic (no-domain) hiding rules
            sel = line[2:].strip()
            if not sel or sel in seen or '{' in sel or '}' in sel or sel.startswith('+js') or ':-abp-' in sel or ':style(' in sel or ':remove(' in sel:
                continue
            seen.add(sel)
            sels.append(sel)
    return sels


if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    easylist = convert(['easylist_easylist_adservers.txt', 'easylist_easylist_thirdparty.txt', 'easylist_easylist_general_block.txt'])
    privacy = convert(['easyprivacy_easyprivacy_trackingservers.txt', 'easyprivacy_easyprivacy_thirdparty.txt', 'easyprivacy_easyprivacy_general.txt'])
    annoy = convert(['easylist_cookie_easylist_cookie_general_block.txt'])
    for name, rules in (('easylist', easylist), ('easyprivacy', privacy), ('annoyances', annoy)):
        (OUT / f'{name}.json').write_text(json.dumps(rules, separators=(',', ':')))
        print(name, len(rules), 'rules')
    ads = cosmetic(['easylist_general_hide.txt'])
    ann = cosmetic(['easylist_cookie_easylist_cookie_general_hide.txt', 'fanboy-addon_fanboy_annoyance_general_hide.txt'])
    json.dump({'ads': ads, 'annoyances': ann}, open(HERE / 'selectors_raw.json', 'w'))
    print('cosmetic ads', len(ads), 'annoyances', len(ann))
