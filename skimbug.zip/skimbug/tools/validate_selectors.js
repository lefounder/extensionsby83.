// Keep only selectors Chrome understands, then write one CSS rule per selector.
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
(async () => {
  const raw = JSON.parse(fs.readFileSync(path.join(__dirname, 'selectors_raw.json'), 'utf8'));
  const b = await chromium.launch(); const p = await b.newPage();
  const out = {};
  for (const k of Object.keys(raw)) {
    out[k] = await p.evaluate(list => list.filter(s => { try { return CSS.supports(`selector(${s})`) && (document.querySelector(s), true); } catch (e) { return false; } }), raw[k]);
    console.log(k, raw[k].length, '->', out[k].length);
  }
  await b.close();
  const rules = path.join(__dirname, '..', 'rules');
  fs.writeFileSync(path.join(rules, 'cosmetic-ads.css'), out.ads.map(s => `${s}:not([data-sb-peek]){display:none!important}`).join('\n'));
  fs.writeFileSync(path.join(rules, 'cosmetic-annoyances.css'), out.annoyances.map(s => `${s}:not([data-sb-peek]){display:none!important}`).join('\n'));
  fs.writeFileSync(path.join(rules, 'selectors.json'), JSON.stringify(out));
})();
