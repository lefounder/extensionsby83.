// Skimbug crawler engine, shared by the page (content.js) and the side panel gallery.
// Procedural: segment chains, two-bone legs with neighbour-gated stepping, chip bodies. No images, no network.
self.SBC = self.SBC || (() => {
'use strict';
const env = { words: [], S: {}, mouse: { on: false, x: 0, y: 0, speed: 0 }, markWord() {}, fxs: [] };
const TAU = Math.PI * 2, HP = Math.PI / 2;
const rnd = (a, b) => a + Math.random() * (b - a);
const ri = (a, b) => Math.floor(rnd(a, b + 1));
const pick = a => a[(Math.random() * a.length) | 0];
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const ad = (a, b) => { let d = (b - a) % TAU; if (d > Math.PI) d -= TAU; else if (d < -Math.PI) d += TAU; return d; };
const ease = t => t < .5 ? 2 * t * t : 1 - (-2 * t + 2) * (-2 * t + 2) / 2;
const rgbC = new Map();
function A(hex, a) { let c = rgbC.get(hex); if (!c) { const n = parseInt(hex.slice(1), 16); c = [n >> 16, (n >> 8) & 255, n & 255]; rgbC.set(hex, c); } return `rgba(${c[0]},${c[1]},${c[2]},${clamp(a, 0, 1)})`; }
const PALS = {
  ember: { line: '#ff4b2b', core: '#ffb057', solid: false }, ion: { line: '#2f7dff', core: '#3fe2ff', solid: false },
  rose: { line: '#ff3d86', core: '#ffc2dc', solid: false }, moss: { line: '#16c95a', core: '#9be82a', solid: true },
  volt: { line: '#00b8d4', core: '#7af2ff', solid: false }, amber: { line: '#e89a00', core: '#ffd36b', solid: true },
};
const KINDS = {
  centipede: { speed: [150, 200], turn: 5.6, maxBend: .38, wander: .45, biteR: 14, pause: [.14, .28], stepDur: .065, reachF: .6, thrF: .3, mul: () => 1,
    build() { const n = ri(15, 25), N = [], L = []; for (let i = 0; i < n; i++) { const t = i / (n - 1); N.push({ x: 0, y: 0, h: 0, gap: i === 0 ? 0 : i === 1 ? 11 : 11.5, s: i === 0 ? 12 : lerp(11.5, 6, Math.pow(t, 1.6)) }); }
      for (let i = 2; i < n - 1; i++) { const t = i / (n - 1); for (const side of [1, -1]) L.push({ seg: i, side, along: 0, tilt: lerp(.35, -.45, t), l1: lerp(12, 9, t), l2: lerp(15, 11, t) }); } return { N, L }; } },
  beetle: { speed: [115, 150], turn: 6.2, maxBend: .5, wander: .6, biteR: 16, pause: [.2, .35], stepDur: .085, reachF: .62, thrF: .3,
    mul: c => { const s = Math.sin(c.t * 3 + c.ph[2]); return .18 + .82 * clamp((s + .3) / .9, 0, 1); },
    build() { const N = [{ x: 0, y: 0, h: 0, gap: 0, s: 10 }, { x: 0, y: 0, h: 0, gap: 12, s: 18 }, { x: 0, y: 0, h: 0, gap: 22, s: 26 }], L = [];
      for (const [along, tilt, l1, l2] of [[6, .8, 15, 19], [0, .05, 16, 21], [-6, -.75, 19, 24]]) for (const side of [1, -1]) L.push({ seg: 1, side, along, tilt, l1, l2 }); return { N, L }; } },
  spider: { speed: [150, 190], turn: 7, maxBend: .6, wander: .7, biteR: 15, pause: [.25, .45], stepDur: .07, reachF: .66, thrF: .26,
    mul: c => { const s = Math.max(0, Math.sin(c.t * 3.6 + c.ph[2])); return .1 + 1.6 * s * s * s; },
    build() { const N = [{ x: 0, y: 0, h: 0, gap: 0, s: 11 }, { x: 0, y: 0, h: 0, gap: 14, s: 17 }], L = [];
      for (const [along, tilt, l1, l2] of [[4, 1.05, 24, 30], [1.5, .4, 22, 26], [-1, -.3, 21, 25], [-3.5, -.95, 24, 30]]) for (const side of [1, -1]) L.push({ seg: 0, side, along, tilt, l1, l2 }); return { N, L }; } },
  scorpion: { speed: [110, 150], turn: 5.2, maxBend: .42, wander: .5, biteR: 15, pause: [.3, .5], stepDur: .08, reachF: .62, thrF: .28,
    mul: c => .5 + .5 * clamp(Math.sin(c.t * 1.5 + c.ph[2]) * 2 + .6, 0, 1),
    build() { const N = [{ x: 0, y: 0, h: 0, gap: 0, s: 11 }, { x: 0, y: 0, h: 0, gap: 12, s: 15 }, { x: 0, y: 0, h: 0, gap: 13, s: 13 }, { x: 0, y: 0, h: 0, gap: 11, s: 11 }, { x: 0, y: 0, h: 0, gap: 10, s: 9 }], L = [];
      for (const [along, tilt, l1, l2] of [[5, .95, 14, 17], [2, .35, 15, 18], [-1, -.25, 15, 18], [-4, -.8, 16, 20]]) for (const side of [1, -1]) L.push({ seg: 1, side, along, tilt, l1, l2 }); return { N, L }; } },
};
function knee(ax, ay, fx, fy, l1, l2, bend) {
  const dx = fx - ax, dy = fy - ay, d = clamp(Math.hypot(dx, dy) || .001, Math.abs(l1 - l2) + .5, l1 + l2 - .5);
  const a = Math.atan2(dy, dx), k = Math.acos(clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1));
  return [ax + Math.cos(a + bend * k) * l1, ay + Math.sin(a + bend * k) * l1];
}

class Crawler {
  constructor(kind, x, y, a, palKey) {
    const k = KINDS[kind]; this.k = k; this.kind = kind; this.pal = PALS[palKey && PALS[palKey] ? palKey : pick(Object.keys(PALS))];
    this.base = rnd(k.speed[0], k.speed[1]); this.v = 0; this.t = rnd(0, 50); this.ph = [rnd(0, TAU), rnd(0, TAU), rnd(0, TAU)];
    const { N, L } = k.build(); this.N = N; this.L = L;
    const ord = { '1': 0, '-1': 0 };
    for (const l of L) { l.ord = ord[l.side]++; l.bend = (l.tilt >= 0 ? 1 : -1) * l.side; l.reach = (l.l1 + l.l2) * k.reachF; l.thr = (l.l1 + l.l2) * k.thrF; l.st = false; l.t = 0; l.lift = 0; }
    for (const l of L) l.nb = L.filter(o => o !== l && ((o.side !== l.side && o.ord === l.ord) || (o.side === l.side && Math.abs(o.ord - l.ord) === 1)));
    this.layout(x, y, a); this.state = 'seek'; this.target = -1; this.giveUp = 0; this.biteT = 0; this.glitch = 0;
    if (kind === 'beetle') { this.bits = Array.from({ length: 12 }, () => Math.random() < .45); this.cellCol = Array.from({ length: 12 }, () => pick([this.pal.core, this.pal.line])); }
  }
  layout(x, y, a) { this.a = a; let px = x, py = y; for (const n of this.N) { px -= Math.cos(a) * n.gap; py -= Math.sin(a) * n.gap; n.x = px; n.y = py; n.h = a; } for (const l of this.L) { this.legRest(l); l.fx = l.rx; l.fy = l.ry; l.st = false; l.lift = 0; } this.tail = null; }
  legRest(l) { const n = this.N[l.seg], ch = Math.cos(n.h), sh = Math.sin(n.h), hw = n.s * .5; l.ax = n.x + ch * l.along - sh * l.side * hw; l.ay = n.y + sh * l.along + ch * l.side * hw; const d = n.h + l.side * (HP - l.tilt); l.rx = l.ax + Math.cos(d) * l.reach; l.ry = l.ay + Math.sin(d) * l.reach; }
  release() { if (this.target >= 0 && env.words[this.target]) env.words[this.target].busy = 0; this.target = -1; }
  pickTarget(now) {
    this.release(); const head = this.N[0];
    const x0 = scrollX + 20, x1 = scrollX + innerWidth - 20, y0 = scrollY + 30, y1 = scrollY + innerHeight - 30;
    const cand = [], pri = [];
    for (let i = 0; i < env.words.length; i++) {
      const w = env.words[i]; if (w.len < 3 || w.busy || w.hlUntil > now || !w.w) continue;
      if (w.cx < x0 || w.cx > x1 || w.cy < y0 || w.cy > y1) continue;
      const d = Math.hypot(w.cx - head.x, w.cy - head.y); if (d < 50) continue;
      (w.pri ? pri : cand).push([d, i]);
    }
    this.giveUp = this.t + 6;
    const pool = pri.length && Math.random() < .8 ? pri : cand;
    if (!pool.length) { this.giveUp = this.t + 1; return; }
    pool.sort((p, q) => p[0] - q[0]);
    const idx = pool[Math.floor(Math.pow(Math.random(), 1.5) * Math.min(pool.length, 14))][1];
    env.words[idx].busy = 1; this.target = idx;
  }
  bite(w, now) { this.state = 'bite'; this.biteT = rnd(this.k.pause[0], this.k.pause[1]); w.busy = 0; this.target = -1; env.markWord(w, this.pal.line, now); w.pri = false; env.fxs.push({ x: w.cx, y: w.cy, w: w.w, h: w.h, r: 0, a: 1, col: this.pal.line }); if (Math.random() < .35) this.glitch = .12; }
  keepNear() {
    const head = this.N[0], m = 450, vx = scrollX, vy = scrollY, vw = innerWidth, vh = innerHeight;
    if (head.y < vy - m || head.y > vy + vh + m || head.x < vx - m || head.x > vx + vw + m) { const above = head.y < vy; this.layout(rnd(vx + vw * .15, vx + vw * .6), above ? vy + 10 : vy + vh + 30, above ? HP : -HP); this.release(); this.state = 'seek'; }
  }
  update(dt, now) {
    const k = this.k, N = this.N, head = N[0];
    if (this.demo) { // gallery preview: walk a loop around the card's centre
      this.t += dt; const d = this.demo; d.t += dt;
      const tx = Math.cos(d.t * .7) * d.r, ty = Math.sin(d.t * .7) * d.r * .45;
      const diff = ad(this.a, Math.atan2(ty - head.y, tx - head.x)), tr = k.turn * dt;
      this.a += clamp(diff, -tr, tr);
      const vt = this.base * .45 * k.mul(this) * (.3 + .7 * Math.max(0, Math.cos(diff)));
      this.v += (vt - this.v) * Math.min(1, dt * 6);
      return this.integrate(dt);
    }
    if (env.S.followMouse && env.mouse.on) {
      this.t += dt; if (this.target >= 0) this.release(); this.state = 'seek';
      const dx = env.mouse.x - head.x, dy = env.mouse.y - head.y, dist = Math.hypot(dx, dy);
      const diff = ad(this.a, Math.atan2(dy, dx)), tr = k.turn * 1.8 * dt;
      if (dist > 6) this.a += clamp(diff, -tr, tr);
      const vt = dist < 16 ? 0 : Math.min(950, env.mouse.speed + (dist - 16) * 2.4) * (.3 + .7 * Math.max(0, Math.cos(diff)));
      this.v += (vt - this.v) * Math.min(1, dt * 10);
      this.integrate(dt);
      for (const w of env.words) {
        if (w.len < 2 || w.hlUntil > now || !w.w) continue;
        if (head.x > w.x - 4 && head.x < w.x + w.w + 4 && head.y > w.y - 4 && head.y < w.y + w.h + 4) { env.markWord(w, this.pal.line, now); env.fxs.push({ x: w.cx, y: w.cy, w: w.w, h: w.h, r: 0, a: .8, col: this.pal.line }); }
      }
      return;
    }
    this.t += dt; this.glitch = Math.max(0, this.glitch - dt); if (Math.random() < dt * .2) this.glitch = rnd(.05, .1);
    this.keepNear();
    let desired = this.a, dist = 1e9, w = null;
    if (this.state === 'seek') {
      if (this.target < 0 || this.t > this.giveUp) this.pickTarget(now);
      w = this.target >= 0 ? env.words[this.target] : null;
      if (w) { const dx = w.cx - head.x, dy = w.cy - head.y; dist = Math.hypot(dx, dy); desired = Math.atan2(dy, dx); }
      else { desired = Math.atan2(scrollY + innerHeight / 2 - head.y, scrollX + innerWidth / 2 - head.x); dist = 200; }
      desired += (Math.sin(this.t * 2 + this.ph[0]) * .6 + Math.sin(this.t * .7 + this.ph[1]) * .4) * k.wander * clamp((dist - 40) / 200, 0, 1);
    }
    let fear = 0;
    if (env.mouse.on) { const dx = head.x - env.mouse.x, dy = head.y - env.mouse.y, d = Math.hypot(dx, dy); if (d < 140) { fear = 1 - d / 140; desired += ad(desired, Math.atan2(dy, dx)) * Math.min(1, fear * 1.6); if (this.state === 'bite' && fear > .4) this.state = 'seek'; } }
    const diff = ad(this.a, desired);
    if (this.state === 'seek' || fear > 0) { const tr = k.turn * (1 + fear) * dt; this.a += clamp(diff, -tr, tr); }
    let vt = 0;
    if (this.state === 'seek') { vt = this.base * k.mul(this) * (.2 + .8 * Math.max(0, Math.cos(diff))); if (dist < 90) vt *= clamp(dist / 90, .3, 1); }
    else { this.biteT -= dt; this.a += Math.sin(this.t * 40) * dt * .8; if (this.biteT <= 0) { this.state = 'seek'; this.pickTarget(now); } }
    vt = Math.max(vt, this.base * 1.6 * fear);
    this.v += (vt - this.v) * Math.min(1, dt * (this.state === 'bite' ? 14 : 6));
    if (w && this.state === 'seek' && dist < k.biteR) this.bite(w, now);
    this.integrate(dt);
  }
  integrate(dt) {
    const k = this.k, N = this.N, head = N[0];
    head.x += Math.cos(this.a) * this.v * dt; head.y += Math.sin(this.a) * this.v * dt; head.h = this.a;
    for (let i = 1; i < N.length; i++) { const p = N[i - 1], c = N[i], back = p.h + Math.PI; let ang = Math.atan2(c.y - p.y, c.x - p.x); ang = back + clamp(ad(back, ang), -k.maxBend, k.maxBend); c.x = p.x + Math.cos(ang) * c.gap; c.y = p.y + Math.sin(ang) * c.gap; c.h = ang + Math.PI; }
    for (const l of this.L) {
      this.legRest(l);
      if (l.st) { l.t += dt / k.stepDur; const e = ease(Math.min(1, l.t)); l.fx = lerp(l.sx, l.tx, e); l.fy = lerp(l.sy, l.ty, e); l.lift = Math.sin(Math.PI * Math.min(1, l.t)); if (l.t >= 1) { l.st = false; l.lift = 0; } }
      else { const d = Math.hypot(l.fx - l.rx, l.fy - l.ry); if ((d > l.thr && !l.nb.some(o => o.st)) || d > l.reach * 1.4) { const n = N[l.seg], lead = Math.min(this.v * k.stepDur * 1.1, l.thr); l.sx = l.fx; l.sy = l.fy; l.tx = l.rx + Math.cos(n.h) * lead; l.ty = l.ry + Math.sin(n.h) * lead; l.st = true; l.t = 0; } }
    }
    if (this.kind === 'beetle' && Math.random() < dt * 3) { const i = ri(0, 11); this.bits[i] = !this.bits[i]; }
    if (this.kind === 'scorpion') this.moveTail(dt);
  }
  moveTail(dt) {
    const N = this.N, last = N[N.length - 1], LEN = [9, 8.4, 7.8, 7.2, 6.6, 6];
    let tl = this.tail;
    if (!tl || Math.hypot(tl.p[0].x - last.x, tl.p[0].y - last.y) > 60) {
      tl = this.tail = { p: [], turn: 0, lastA: this.a, gait: rnd(0, TAU), side: Math.random() < .5 ? 1 : -1, tipA: 0 };
      let a = last.h + Math.PI, x = last.x, y = last.y;
      for (let i = 0; i < 6; i++) { a += .42 * tl.side * (i < 1 ? .3 : 1); x += Math.cos(a) * LEN[i]; y += Math.sin(a) * LEN[i]; tl.p.push({ x, y, vx: 0, vy: 0, h: a + Math.PI }); }
    }
    tl.turn += (clamp(ad(tl.lastA, this.a) / Math.max(dt, 1e-3), -8, 8) - tl.turn) * Math.min(1, dt * 6); tl.lastA = this.a;
    tl.gait += this.v * dt * .09;
    const wag = Math.sin(tl.gait) * .55 * clamp(this.v / 110, 0, 1);
    let ax = last.x, ay = last.y, a = last.h + Math.PI;
    for (let i = 0; i < 6; i++) {
      const q = tl.p[i];
      a += .42 * tl.side * (i < 1 ? .3 : 1) + wag * (i < 1 ? .6 : .35) - tl.turn * .05;
      const tx = ax + Math.cos(a) * LEN[i], ty = ay + Math.sin(a) * LEN[i], kk = 140 - i * 18, damp = 12 - i;
      q.vx += ((tx - q.x) * kk - q.vx * damp) * dt; q.vy += ((ty - q.y) * kk - q.vy * damp) * dt;
      q.x += q.vx * dt; q.y += q.vy * dt;
      const dx = q.x - ax, dy = q.y - ay, d = Math.hypot(dx, dy) || 1;
      q.x = ax + dx / d * LEN[i]; q.y = ay + dy / d * LEN[i];
      a = Math.atan2(q.y - ay, q.x - ax); q.h = a + Math.PI; ax = q.x; ay = q.y;
    }
    tl.tipA = a;
  }
  draw(g) {
    g.globalAlpha = this.glitch > 0 && Math.random() < .5 ? .35 : 1;
    if (this.state === 'seek' && this.target >= 0 && !this.demo && !env.S.followMouse) {
      const w = env.words[this.target], h = this.N[0], d = Math.hypot(w.cx - h.x, w.cy - h.y);
      if (d < 300) { const a = (1 - d / 300) * .8, x0 = w.x - 4, y0 = w.y - 2, x1 = w.x + w.w + 4, y1 = w.y + w.h + 2, c = 5; g.strokeStyle = A(this.pal.line, a); g.lineWidth = 1; g.beginPath(); g.moveTo(x0, y0 + c); g.lineTo(x0, y0); g.lineTo(x0 + c, y0); g.moveTo(x1 - c, y0); g.lineTo(x1, y0); g.lineTo(x1, y0 + c); g.moveTo(x1, y1 - c); g.lineTo(x1, y1); g.lineTo(x1 - c, y1); g.moveTo(x0 + c, y1); g.lineTo(x0, y1); g.lineTo(x0, y1 - c); g.stroke(); }
    }
    if (this.glitch > 0) { g.save(); g.translate(rnd(-4, 4), 0); }
    this['draw_' + this.kind](g);
    if (this.glitch > 0) g.restore();
    g.globalAlpha = 1;
  }
  drawLegs(g, lw) {
    const p = this.pal; g.lineWidth = lw; g.strokeStyle = A(p.line, .9); g.beginPath();
    for (const l of this.L) { const kp = knee(l.ax, l.ay, l.fx, l.fy, l.l1, l.l2, l.bend); l.kx = kp[0]; l.ky = kp[1]; g.moveTo(l.ax, l.ay); g.lineTo(l.kx, l.ky); g.lineTo(l.fx, l.fy); }
    g.stroke(); g.lineWidth = .9; g.strokeStyle = p.core; g.beginPath(); for (const l of this.L) g.rect(l.kx - 1.6, l.ky - 1.6, 3.2, 3.2); g.stroke();
    for (const l of this.L) { const r = 1.6 + l.lift * 1.2; g.fillStyle = l.st ? p.core : p.line; g.fillRect(l.fx - r, l.fy - r, r * 2, r * 2); }
  }
  chip(g, n, s, i) {
    const p = this.pal, h = s / 2; g.save(); g.translate(n.x, n.y); g.rotate(n.h);
    g.strokeStyle = A(p.line, .8); g.lineWidth = .8; g.beginPath(); for (const q of [-.25, .25]) { g.moveTo(q * s, -h); g.lineTo(q * s, -h - 2.5); g.moveTo(q * s, h); g.lineTo(q * s, h + 2.5); } g.stroke();
    g.fillStyle = '#0b0b12'; g.fillRect(-h, -h, s, s);
    if (p.solid) { g.fillStyle = A(p.core, .9); g.fillRect(-h, -h, s, s); g.fillStyle = '#0b0b12'; g.fillRect(-h + 1.6, -h + 1.6, s - 3.2, s - 3.2); }
    g.strokeStyle = p.line; g.lineWidth = 1.1; g.strokeRect(-h, -h, s, s);
    const q = s * .17, gap = s * .06, step = Math.floor(this.t * 14 - i);
    for (let k = 0; k < 4; k++) { const on = ((step + k) & 3) === 0; g.fillStyle = on ? p.core : A(p.line, .4); g.fillRect(k & 1 ? gap : -gap - q * 2, k & 2 ? gap : -gap - q * 2, q * 2, q * 2); }
    g.restore();
  }
  antennae(g, x, len, spread) {
    const p = this.pal; g.strokeStyle = A(p.line, .9); g.lineWidth = .9;
    for (const side of [1, -1]) { const w = Math.sin(this.t * 7 + side * 1.7 + this.ph[1]) * .12, kx = x + len * .45, ky = side * (2 + len * .1), ex = kx + Math.cos(side * (spread + w)) * len * .55, ey = ky + Math.sin(side * (spread + w)) * len * .55; g.beginPath(); g.moveTo(x, side * 2); g.lineTo(kx, ky); g.lineTo(ex, ey); g.stroke(); g.beginPath(); g.arc(ex, ey, 1.8, 0, TAU); g.stroke(); }
  }
  draw_centipede(g) {
    const N = this.N, p = this.pal, t = this.t; this.drawLegs(g, 1);
    g.strokeStyle = A(p.line, .7); g.lineWidth = 1; g.beginPath(); g.moveTo(N[0].x, N[0].y); for (let i = 1; i < N.length; i++) g.lineTo(N[i].x, N[i].y); g.stroke();
    for (let i = N.length - 1; i >= 1; i--) this.chip(g, N[i], N[i].s, i);
    g.fillStyle = p.core; for (let k = 0; k < 3; k++) { const u = ((t * .9 + k / 3) % 1) * (N.length - 1), i = Math.floor(u), f = u - i, a = N[i], b = N[Math.min(i + 1, N.length - 1)]; g.fillRect(lerp(a.x, b.x, f) - 1.2, lerp(a.y, b.y, f) - 1.2, 2.4, 2.4); }
    const h = N[0], s = h.s; g.save(); g.translate(h.x, h.y); g.rotate(h.h); this.antennae(g, s * .45, 34, .7);
    const op = this.state === 'bite' ? .5 + .5 * Math.sin(t * 40) : .15; g.strokeStyle = p.line; g.lineWidth = 1.3;
    for (const side of [1, -1]) { g.beginPath(); g.moveTo(s * .3, side * s * .4); g.lineTo(s * .95, side * s * (.55 + op * .2)); g.lineTo(s * 1.1, side * s * (.08 + op * .3)); g.stroke(); }
    g.restore(); this.chip(g, h, s, 0);
  }
  draw_beetle(g) {
    const [hd, th, ab] = this.N, p = this.pal, t = this.t; this.drawLegs(g, 1.1);
    g.save(); g.translate(ab.x, ab.y); g.rotate(ab.h); const L = 34, W = 26, cw = L / 4, chh = W / 3;
    g.fillStyle = '#0b0b12'; g.fillRect(-L / 2, -W / 2, L, W);
    for (let r = 0; r < 3; r++) for (let c = 0; c < 4; c++) { const i = r * 4 + c; if (!this.bits[i]) continue; g.fillStyle = A(this.cellCol[i], .6 + .35 * Math.sin(t * 6 + i * 1.3)); g.fillRect(-L / 2 + c * cw + 1.5, -W / 2 + r * chh + 1.5, cw - 3, chh - 3); }
    g.strokeStyle = A(p.line, .5); g.lineWidth = .8; g.beginPath(); for (let c = 1; c < 4; c++) { g.moveTo(-L / 2 + c * cw, -W / 2); g.lineTo(-L / 2 + c * cw, W / 2); } for (let r = 1; r < 3; r++) { g.moveTo(-L / 2, -W / 2 + r * chh); g.lineTo(L / 2, -W / 2 + r * chh); } g.stroke();
    g.strokeStyle = p.line; g.lineWidth = 1.3; g.strokeRect(-L / 2, -W / 2, L, W); g.restore();
    g.save(); g.translate(th.x, th.y); g.rotate(th.h); g.fillStyle = A(p.core, .9); g.fillRect(-6, -9, 12, 18); g.fillStyle = '#0b0b12'; g.fillRect(-3.5, -6, 7, 12); g.strokeStyle = p.line; g.lineWidth = 1.2; g.strokeRect(-6, -9, 12, 18); g.restore();
    g.save(); g.translate(hd.x, hd.y); g.rotate(hd.h); this.antennae(g, 4, 44, .8); g.fillStyle = '#0b0b12'; g.fillRect(-4.5, -5.5, 9, 11); g.strokeStyle = p.line; g.lineWidth = 1.1; g.strokeRect(-4.5, -5.5, 9, 11); g.fillStyle = p.core; g.fillRect(1, -4, 2, 2); g.fillRect(1, 2, 2, 2); g.restore();
  }
  draw_spider(g) {
    const [ce, abd] = this.N, p = this.pal, t = this.t; this.drawLegs(g, 1.25);
    g.save(); g.translate(abd.x, abd.y); g.rotate(abd.h + Math.PI / 4); const s = 17; g.fillStyle = '#0b0b12'; g.fillRect(-s / 2, -s / 2, s, s); g.strokeStyle = p.line; g.lineWidth = 1.2; g.strokeRect(-s / 2, -s / 2, s, s); g.strokeStyle = A(p.core, .85); g.lineWidth = 1; g.strokeRect(-s * .3, -s * .3, s * .6, s * .6); const ring = (t * 3) % 1; g.strokeStyle = A(p.core, 1 - ring); g.strokeRect(-s * .3 * ring, -s * .3 * ring, s * .6 * ring, s * .6 * ring); g.restore();
    g.save(); g.translate(ce.x, ce.y); g.rotate(ce.h); g.fillStyle = A(p.core, .95); g.fillRect(-5.5, -5.5, 11, 11); g.strokeStyle = p.line; g.lineWidth = 1; g.strokeRect(-5.5, -5.5, 11, 11); g.restore();
  }
  draw_scorpion(g) {
    const N = this.N, p = this.pal, t = this.t; this.drawLegs(g, 1.1);
    const last = N[N.length - 1];
    if (this.tail) {
      const pts = this.tail.p, ang = this.tail.tipA;
      g.strokeStyle = A(p.line, .7); g.lineWidth = 1; g.beginPath(); g.moveTo(last.x, last.y); for (const q of pts) g.lineTo(q.x, q.y); g.stroke();
      pts.forEach((q, i) => this.chip(g, q, 8 - i * .7, i + N.length));
      const tip = pts[pts.length - 1];
      g.fillStyle = p.core; g.beginPath(); g.moveTo(tip.x + Math.cos(ang) * 8, tip.y + Math.sin(ang) * 8); g.lineTo(tip.x + Math.cos(ang + 2.4) * 3.5, tip.y + Math.sin(ang + 2.4) * 3.5); g.lineTo(tip.x + Math.cos(ang - 2.4) * 3.5, tip.y + Math.sin(ang - 2.4) * 3.5); g.closePath(); g.fill();
    }
    for (let i = N.length - 1; i >= 1; i--) this.chip(g, N[i], N[i].s, i);
    const h = N[0]; g.save(); g.translate(h.x, h.y); g.rotate(h.h);
    const op = this.state === 'bite' ? .5 + .5 * Math.sin(t * 30) : .25 + Math.sin(t * 3) * .08;
    g.strokeStyle = A(p.line, .95); g.lineWidth = 1.2;
    for (const side of [1, -1]) {
      const ex = 12, ey = side * (14 + Math.sin(t * 4 + side) * 1.5), cx = 22, cy = side * 10;
      g.beginPath(); g.moveTo(3, side * 5); g.lineTo(ex, ey); g.lineTo(cx, cy); g.stroke();
      g.fillStyle = p.core; g.fillRect(ex - 1.6, ey - 1.6, 3.2, 3.2);
      g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + 9, cy + side * (2 + op * 4)); g.moveTo(cx, cy); g.lineTo(cx + 9, cy - side * (1 + op * 3)); g.stroke();
      g.strokeRect(cx - 3, cy - 3, 6, 6);
    }
    g.restore(); this.chip(g, h, h.s, 0);
  }
}
return { env, Crawler, KINDS, PALS, A, rnd, ri, pick, clamp, lerp, TAU, HP };
})();
