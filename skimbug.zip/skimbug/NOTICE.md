# Third-party material

- **EasyList, EasyPrivacy, EasyList Cookie List** (https://easylist.to, https://github.com/easylist/easylist), by The EasyList authors. Dual licensed GPL v3 and CC BY-SA 3.0. Converted into `rules/easylist.json`, `rules/easyprivacy.json`, `rules/annoyances.json` and `rules/cosmetic-*.css`; the source lists are in `tools/lists/`.
- **Fanboy's Annoyance List** (https://secure.fanboy.co.nz), by Fanboy. CC BY 3.0. Part of `rules/cosmetic-annoyances.css`.
- **compromise** 14.17.0 (https://github.com/spencermountain/compromise), by Spencer Kelly. MIT licence, see `lib/compromise-LICENSE.txt`. Used to tag English words by type.
- **IBM Plex Sans, IBM Plex Mono** (IBM) and **Unbounded** (NaN), SIL Open Font License 1.1, see `fonts/`. Packaged by Fontsource.

Everything else in this folder was written for Skimbug.
