// Skimbug background service worker
// - model connections: key detection, validation, calls, fallback, answer cache
// - ad blocking: DNR rulesets, per-site pause, cosmetic CSS registration
// API keys live only in chrome.storage.local on this computer and are sent only to their own provider.

const DEFAULTS = {
  route: '', order: [], fallback: true, limitMode: 'auto', limit: 6000,
  exclude: 'mail.google.com\n*.bank\n*.gov', block: true, paused: [],
  lists: { easylist: true, easyprivacy: true, annoyances: true },
  crawler: true, crawlerKind: 'random', crawlerPal: 'random', hlMode: 'pos', followMouse: false, follow: true,
  focus: 'off', seenGuide: false,
};

const PROVIDERS = {
  gemini: { name: 'Google Gemini', base: 'https://generativelanguage.googleapis.com/v1beta', format: 'gemini', limit: 12000, keyUrl: 'https://aistudio.google.com/apikey' },
  openrouter: { name: 'OpenRouter', base: 'https://openrouter.ai/api/v1', format: 'openai', limit: 8000, keyUrl: 'https://openrouter.ai/keys' },
  groq: { name: 'Groq', base: 'https://api.groq.com/openai/v1', format: 'openai', limit: 6000, keyUrl: 'https://console.groq.com/keys' },
  openai: { name: 'OpenAI', base: 'https://api.openai.com/v1', format: 'openai', limit: 12000 },
  anthropic: { name: 'Anthropic', base: 'https://api.anthropic.com/v1', format: 'anthropic', limit: 12000 },
  deepseek: { name: 'DeepSeek', base: 'https://api.deepseek.com/v1', format: 'openai', limit: 12000 },
  mistral: { name: 'Mistral', base: 'https://api.mistral.ai/v1', format: 'openai', limit: 12000 },
  ollama: { name: 'Ollama', base: 'http://localhost:11434/v1', format: 'openai', limit: 8000, noKey: true },
  custom: { name: 'Custom', base: '', format: 'openai', limit: 8000 },
};

/* ---------------- storage helpers ---------------- */
async function getSettings() { const { settings } = await chrome.storage.local.get('settings'); return { ...DEFAULTS, ...(settings || {}) }; }
async function setSettings(patch) { const s = await getSettings(); const n = { ...s, ...patch }; await chrome.storage.local.set({ settings: n }); return n; }
async function getConnections() { const { connections } = await chrome.storage.local.get('connections'); return connections || []; }
async function setConnections(list) { await chrome.storage.local.set({ connections: list }); }
async function getHealth() { const { health } = await chrome.storage.session.get('health'); return health || {}; }
async function setHealth(h) { await chrome.storage.session.set({ health: h }); }

/* ---------------- install / startup ---------------- */
chrome.runtime.onInstalled.addListener(async () => {
  const { settings } = await chrome.storage.local.get('settings');
  if (!settings) await chrome.storage.local.set({ settings: DEFAULTS });
  await setup();
});
chrome.runtime.onStartup.addListener(setup);
async function setup() {
  try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); } catch (e) {}
  try { await chrome.declarativeNetRequest.setExtensionActionOptions({ displayActionCountAsBadgeText: true }); } catch (e) {}
  chrome.action.setBadgeBackgroundColor({ color: '#04060B' });
  try { chrome.action.setBadgeTextColor({ color: '#00E5FF' }); } catch (e) {}
  await syncBlocking();
}

/* ---------------- ad blocking ---------------- */
const RULESETS = ['easylist', 'easyprivacy', 'annoyances'];
let syncChain = Promise.resolve();
function syncBlocking() { syncChain = syncChain.then(doSync, doSync); return syncChain; }
async function doSync() {
  const s = await getSettings();
  const on = RULESETS.filter(id => s.block && s.lists[id] !== false);
  const off = RULESETS.filter(id => !on.includes(id));
  await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: on, disableRulesetIds: off });
  // paused sites: allow everything they load
  const old = await chrome.declarativeNetRequest.getDynamicRules();
  const add = (s.paused || []).map((host, i) => ({
    id: i + 1, priority: 100, action: { type: 'allowAllRequests' },
    condition: { requestDomains: [host], resourceTypes: ['main_frame', 'sub_frame'] },
  }));
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: old.map(r => r.id), addRules: add });
  // cosmetic CSS, injected at document start on every site except paused ones
  const ids = ['cosm-ads', 'cosm-annoy'];
  try { await chrome.scripting.unregisterContentScripts({ ids }); } catch (e) {}
  const excludeMatches = (s.paused || []).flatMap(h => [`*://${h}/*`, `*://*.${h}/*`]);
  const reg = [];
  if (s.block && s.lists.easylist !== false) reg.push({ id: 'cosm-ads', css: ['rules/cosmetic-ads.css'] });
  if (s.block && s.lists.annoyances !== false) reg.push({ id: 'cosm-annoy', css: ['rules/cosmetic-annoyances.css'] });
  if (reg.length) await chrome.scripting.registerContentScripts(reg.map(r => ({ ...r, matches: ['http://*/*', 'https://*/*'], excludeMatches, runAt: 'document_start', allFrames: true, persistAcrossSessions: true })));
}
async function blockStats(tabId) {
  try {
    const { rulesMatchedInfo } = await chrome.declarativeNetRequest.getMatchedRules({ tabId });
    const by = {};
    for (const m of rulesMatchedInfo) by[m.rule.rulesetId] = (by[m.rule.rulesetId] || 0) + 1;
    return { total: rulesMatchedInfo.length, by };
  } catch (e) { return { total: 0, by: {}, error: String(e.message || e) }; }
}

/* ---------------- key detection and connection ---------------- */
function detect(key) {
  const k = key.trim();
  if (/^AIza[0-9A-Za-z_-]{20,}$/.test(k)) return { provider: 'gemini' };
  if (/^sk-or-/.test(k)) return { provider: 'openrouter' };
  if (/^gsk_/.test(k)) return { provider: 'groq' };
  if (/^sk-ant-/.test(k)) return { provider: 'anthropic' };
  if (/^sk-proj-/.test(k)) return { provider: 'openai' };
  if (/^sk-/.test(k)) return { choices: ['openai', 'deepseek', 'custom'] };
  return { choices: ['mistral', 'custom'] };
}
function headers(c) {
  if (c.format === 'gemini') return { 'Content-Type': 'application/json', 'x-goog-api-key': c.key };
  if (c.format === 'anthropic') return { 'Content-Type': 'application/json', 'x-api-key': c.key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' };
  const h = { 'Content-Type': 'application/json' };
  if (c.key) h.Authorization = 'Bearer ' + c.key;
  if (c.provider === 'openrouter') { h['HTTP-Referer'] = 'https://skimbug.app'; h['X-Title'] = 'Skimbug'; }
  return h;
}
async function timed(url, opts, ms = 30000) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
  try { return await fetch(url, { ...opts, signal: ctl.signal }); } finally { clearTimeout(t); }
}
// Pick a sensible default model from the provider's own list, so we never hard-code a retired name.
function chooseModel(provider, ids) {
  const pick = (...tests) => { for (const t of tests) { const m = ids.find(t); if (m) return m; } return ids[0]; };
  if (provider === 'gemini') return pick(i => /flash-lite/.test(i) && !/preview|exp|tts|image|live/.test(i), i => /flash/.test(i) && !/preview|exp|tts|image|live/.test(i));
  if (provider === 'openrouter') return pick(i => /:free$/.test(i) && /(gemini|llama|qwen|gemma|mistral|deepseek)/.test(i), i => /:free$/.test(i));
  if (provider === 'groq') return pick(i => /gpt-oss-120b/.test(i), i => /(llama|qwen|gpt-oss)/.test(i) && !/whisper|guard|tts/.test(i));
  if (provider === 'openai') return pick(i => /^gpt-[\d.]+-mini$/.test(i), i => /^gpt/.test(i) && /mini/.test(i) && !/audio|realtime|transcribe|tts|search|image/.test(i), i => /^gpt/.test(i));
  if (provider === 'anthropic') return pick(i => /haiku/.test(i), i => /sonnet/.test(i));
  if (provider === 'mistral') return pick(i => /mistral-small-latest/.test(i), i => /small/.test(i));
  if (provider === 'deepseek') return pick(i => /deepseek-chat/.test(i));
  return ids[0];
}
async function listModels(c) {
  if (c.format === 'gemini') {
    const r = await timed(`${c.base}/models?pageSize=200`, { headers: headers(c) }, 15000);
    if (!r.ok) throw await httpError(r);
    const j = await r.json();
    return (j.models || []).filter(m => (m.supportedGenerationMethods || []).includes('generateContent')).map(m => m.name.replace(/^models\//, ''));
  }
  const r = await timed(`${c.base}/models`, { headers: headers(c) }, 15000);
  if (!r.ok) throw await httpError(r);
  const j = await r.json();
  return (j.data || j.models || []).map(m => m.id || m.name).filter(Boolean);
}
async function connect({ provider, key, base, model, name }) {
  const p = PROVIDERS[provider] || PROVIDERS.custom;
  const c = { id: 'c' + Date.now().toString(36), provider, name: name || p.name, key: (key || '').trim(), base: (base || p.base).replace(/\/+$/, ''), format: p.format, limit: p.limit, model: model || '' };
  if (!c.base) return { ok: false, error: 'Add the API address for this provider.' };
  if (!c.key && !p.noKey) return { ok: false, error: 'Paste the key first.' };
  let ids = [];
  try { ids = await listModels(c); }
  catch (e) { return { ok: false, error: explain(e).text, kind: explain(e).kind }; }
  if (!c.model) c.model = chooseModel(provider, ids);
  if (!c.model) return { ok: false, error: 'The key works, but this account has no models Skimbug can use.' };
  if (provider === 'openrouter') c.name = 'OpenRouter (free models)';
  const list = await getConnections(); list.push(c); await setConnections(list);
  const s = await getSettings();
  const order = [...(s.order || []).filter(id => list.some(x => x.id === id)), c.id];
  await setSettings({ order, route: s.route && list.some(x => x.id === s.route) ? s.route : c.id });
  return { ok: true, connection: publicConn(c), models: ids.slice(0, 200) };
}
const publicConn = c => ({ id: c.id, provider: c.provider, name: c.name, model: c.model, base: c.base, keyHint: c.key ? c.key.slice(0, 6) + '…' + c.key.slice(-4) : '' });

/* ---------------- calling models ---------------- */
class HttpErr extends Error { constructor(status, body, retryAfter) { super(`HTTP ${status}`); this.status = status; this.body = body; this.retryAfter = retryAfter; } }
async function httpError(r) { let body = ''; try { body = await r.text(); } catch (e) {} return new HttpErr(r.status, body.slice(0, 600), Number(r.headers.get('retry-after')) || 0); }
function explain(e) {
  if (e && e.name === 'AbortError') return { kind: 'down', text: 'did not answer in 30 seconds', rest: 2 * 60e3 };
  if (e instanceof HttpErr) {
    if (/location is not supported|not available in your country|unsupported_country|region/i.test(e.body)) return { kind: 'region', text: 'is not available in your country', rest: Infinity };
    if (e.status === 401 || e.status === 403) return { kind: 'auth', text: 'rejected the key', rest: Infinity };
    if (e.status === 429) return { kind: 'limit', text: 'ran out of free requests', rest: (e.retryAfter || 15 * 60) * 1000 };
    if (e.status === 404) return { kind: 'model', text: 'does not have that model any more', rest: Infinity };
    if (e.status === 413) return { kind: 'size', text: 'could not take a page this long', rest: 0 };
    if (e.status >= 500) return { kind: 'down', text: 'is having problems on its side', rest: 2 * 60e3 };
    return { kind: 'bad', text: `refused the request (${e.status})`, rest: 60e3 };
  }
  if (e && e.kind === 'format') return { kind: 'format', text: 'sent an answer Skimbug could not read', rest: 0 };
  return { kind: 'down', text: 'could not be reached', rest: 2 * 60e3 };
}
function parseJSON(text) {
  try { return JSON.parse(text); } catch (e) {}
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/); if (fence) { try { return JSON.parse(fence[1]); } catch (e) {} }
  const a = text.indexOf('{'), b = text.lastIndexOf('}');
  if (a >= 0 && b > a) { try { return JSON.parse(text.slice(a, b + 1)); } catch (e) {} }
  const err = new Error('format'); err.kind = 'format'; throw err;
}
async function callModel(c, prompt) {
  if (c.format === 'gemini') {
    const r = await timed(`${c.base}/models/${encodeURIComponent(c.model)}:generateContent`, { method: 'POST', headers: headers(c),
      body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', temperature: 0.3 } }) });
    if (!r.ok) throw await httpError(r);
    const j = await r.json();
    return parseJSON((j.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join(''));
  }
  if (c.format === 'anthropic') {
    const r = await timed(`${c.base}/messages`, { method: 'POST', headers: headers(c), body: JSON.stringify({ model: c.model, max_tokens: 1500, temperature: 0.3, messages: [{ role: 'user', content: prompt }] }) });
    if (!r.ok) throw await httpError(r);
    const j = await r.json();
    return parseJSON((j.content || []).map(p => p.text || '').join(''));
  }
  const body = { model: c.model, temperature: 0.3, messages: [{ role: 'user', content: prompt }], response_format: { type: 'json_object' } };
  let r = await timed(`${c.base}/chat/completions`, { method: 'POST', headers: headers(c), body: JSON.stringify(body) });
  if (r.status === 400) { delete body.response_format; r = await timed(`${c.base}/chat/completions`, { method: 'POST', headers: headers(c), body: JSON.stringify(body) }); }
  if (!r.ok) throw await httpError(r);
  const j = await r.json();
  return parseJSON(j.choices?.[0]?.message?.content || '');
}

/* ---------------- prompts ---------------- */
function buildPrompt(page, lang, onlyScreen, limitTokens) {
  const vis = new Set(page.visible || []), budget = limitTokens * 4;
  let lines = page.paras.map((p, i) => `[P${i + 1}]${vis.has(i) ? '[ON SCREEN]' : ''}${p.head ? ' ##' : ''} ${p.text}`);
  if (onlyScreen) lines = lines.filter((_, i) => vis.has(i));
  let body = lines.join('\n');
  if (body.length > budget) body = lines.filter((l, i) => i < 4 || vis.has(i)).join('\n').slice(0, budget);
  const L = lang === 'ru' ? 'Russian' : 'English';
  if (onlyScreen) return `You summarize what a reader currently sees in a browser window. Write in ${L}.\nReturn ONLY JSON: {"onScreen": [3-5 short sentences]} covering ONLY these visible paragraphs, concrete facts and numbers first, no filler.\n\nVISIBLE PARAGRAPHS:\n${body}`;
  const links = (page.links || []).slice(0, 30).map(l => `${l.id} | ${l.text} | ${l.host} | context: ${l.ctx}`).join('\n');
  const side = (page.side || []).slice(0, 20).map(s => `${s.id} | ${s.text} | block: ${s.block}`).join('\n');
  return `You are the summarizer inside a browser extension called Skimbug. The extension already removed menus, ads and footers; you get the cleaned article, a list of its links, and headlines from side boxes of the same page.
Write every string in ${L}. Plain text, no markdown.
Return ONLY JSON with this shape:
{"about": "2-3 sentences: what the page is about and the main finding",
 "onScreen": ["3-5 sentences that retell ONLY the paragraphs marked [ON SCREEN], concrete facts and numbers first"],
 "keyLinks": [{"id": "L#", "why": "one short reason this link is worth opening"}],
 "worthNoting": [{"id": "S#", "why": "one short reason"}]}
Rules: keyLinks 3-5 ids taken only from LINKS. worthNoting 0-3 ids taken only from SIDE, only items a reader of THIS article would genuinely want; skip clickbait and unrelated items. If no paragraph is marked [ON SCREEN], base onScreen on the first paragraphs.

PAGE: ${page.title} (${page.host})

ARTICLE:
${body}

LINKS:
${links || '(none)'}

SIDE:
${side || '(none)'}`;
}

/* ---------------- cache ---------------- */
async function hash(s) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return [...new Uint8Array(b)].slice(0, 12).map(x => x.toString(16).padStart(2, '0')).join(''); }
async function cacheGet(k) { const { cache } = await chrome.storage.local.get('cache'); const e = (cache || {})[k]; return e && Date.now() - e.at < 7 * 864e5 ? e.v : null; }
async function cachePut(k, v) {
  const { cache = {} } = await chrome.storage.local.get('cache'); cache[k] = { at: Date.now(), v };
  const keys = Object.keys(cache); if (keys.length > 150) keys.sort((a, b) => cache[a].at - cache[b].at).slice(0, keys.length - 150).forEach(x => delete cache[x]);
  await chrome.storage.local.set({ cache });
}

/* ---------------- summarize with fallback ---------------- */
async function summarize({ page, lang, onlyScreen }) {
  const s = await getSettings(), list = await getConnections(), health = await getHealth();
  if (!list.length) return { ok: false, code: 'no_models', skipped: [] };
  const byId = id => list.find(c => c.id === id);
  const first = byId(s.route) || list[0];
  const rest = (s.order || []).map(byId).filter(c => c && c !== first);
  list.forEach(c => { if (c !== first && !rest.includes(c)) rest.push(c); });
  const chain = [first, ...(s.fallback ? rest : [])];
  const textKey = await hash(page.paras.map(p => p.text).join('\n') + (onlyScreen ? (page.visible || []).join(',') : ''));
  const skipped = [];
  for (const c of chain) {
    const h = health[c.id];
    if (h && h.until > Date.now()) { skipped.push({ name: c.name, why: h.why, until: h.until }); continue; }
    const limit = s.limitMode === 'auto' ? c.limit : s.limit;
    const key = `${page.url}|${lang}|${onlyScreen ? 's' : 'a'}|${c.id}|${c.model}|${textKey}`;
    const cached = await cacheGet(key);
    if (cached) return { ok: true, out: cached, used: publicConn(c), skipped, cached: true };
    try {
      const out = await callModel(c, buildPrompt(page, lang, onlyScreen, limit));
      await cachePut(key, out);
      return { ok: true, out, used: publicConn(c), skipped };
    } catch (e) {
      const x = explain(e);
      if (x.rest) { health[c.id] = { until: x.rest === Infinity ? 8.64e15 : Date.now() + x.rest, why: x.text }; await setHealth(health); }
      skipped.push({ name: c.name, why: x.text, until: x.rest && x.rest !== Infinity ? Date.now() + x.rest : 0 });
      if (!s.fallback) return { ok: false, code: 'no_fallback', skipped };
    }
  }
  return { ok: false, code: 'all_failed', skipped };
}

/* ---------------- messages from the side panel ---------------- */
let selectorsCache = null;
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.to === 'panel') return false; // page updates meant for the side panel only
  const run = async () => {
    switch (msg.type) {
      case 'detect': return detect(msg.key || '');
      case 'connect': return connect(msg);
      case 'disconnect': {
        const list = (await getConnections()).filter(c => c.id !== msg.id); await setConnections(list);
        const s = await getSettings(); await setSettings({ order: s.order.filter(id => id !== msg.id), route: s.route === msg.id ? (list[0]?.id || '') : s.route });
        return { ok: true };
      }
      case 'connections': {
        const list = await getConnections(), health = await getHealth();
        return { list: list.map(publicConn), health, providers: Object.fromEntries(Object.entries(PROVIDERS).map(([k, v]) => [k, { name: v.name, base: v.base, keyUrl: v.keyUrl || '', noKey: !!v.noKey }])) };
      }
      case 'resetHealth': { const h = await getHealth(); delete h[msg.id]; await setHealth(h); return { ok: true }; }
      case 'summarize': return summarize(msg);
      case 'syncBlocking': await syncBlocking(); return { ok: true };
      case 'blockStats': return blockStats(msg.tabId);
      case 'selectors': {
        if (!selectorsCache) selectorsCache = await (await fetch(chrome.runtime.getURL('rules/selectors.json'))).json();
        const s = await getSettings();
        return { ads: s.lists.easylist !== false ? selectorsCache.ads : [], annoyances: s.lists.annoyances !== false ? selectorsCache.annoyances : [] };
      }
      case 'injectNlp': {
        try { await chrome.scripting.executeScript({ target: { tabId: sender.tab.id }, files: ['lib/compromise.js'] }); return { ok: true }; }
        catch (e) { return { ok: false }; }
      }
      default: return { error: 'unknown message' };
    }
  };
  run().then(reply, e => reply({ ok: false, error: String(e && e.message || e) }));
  return true;
});
